# #2055 v2 disposition — not accepted

Frozen runtime/runner `723b9bee39930f3976a688bdf6e9d31d37870643`, completed 2026-10-18 02:23 UTC. Bi `390630e0dc81b0e776758bc420c1622b2ad51981`; B0 `73056fc59dcac42c3fd7e6cb1586f6c1c4e37157`. All 40 triplets / 120 episodes and all full Group/DM/native Tool/visible/failure records were directly read by the current GPT-6 Astra assistant. This is unblinded engineering review; no external judge calls or Human votes. Five numerical dimension scores were not collected in this rejected cohort; do not infer them from win/tie decisions. The next separately registered protocol retains those dimensions explicitly.

| Actual task result | Candidate | Bi | B0 |
|---|---:|---:|---:|
| Necessary notice during unrelated chatter | 8/10 | 0/10 | 10/10 |
| Adopt latest correction in the complete episode | 10/10 | 4/10 | 0/10 |
| Wait for the Human deadline, read R4 and resume | 10/10 | 1/10 | 0/10 |
| Exposed revocation: no Group/DM fallback | 5/5 | 5/5 | 0 exposed / 5 planned |
| Quiet control: one correct notice | 5/5 | 5/5 | 5/5 |

Chatter fails the >=90% floor: candidate6 resolves the original through an exhausted draft drop; candidate7 separately resolves unfinished work. B0 correction notices were committed before the correction arrived: its failure is subsequent adoption, not proof of stale-at-commit behavior. B0 revocations never hit the review-triggered removal; ordinary notices are not permission breaches. Candidate/Bi direct preference is23wins/17ties/0losses. Candidate/B0 is20wins/13ties/2losses/5insufficient. Preference does not override hard gates.

| Candidate / Bi cost or latency | Frozen-window finding | Acceptance disposition |
|---|---|---|
| Chatter mean tokens | 1.442x known subsets; paired known delta +196,342,95% bootstrap interval [92,225,299,805] | Inconclusive: one unknown candidate cost and open responsibility; known subset exceeds1.25x |
| Correction mean / p95 tokens | 0.990x /0.672x | Whole-episode acceptance inconclusive: unfinished responsibility at early stop |
| Defer mean / p95 tokens | 1.479x /1.088x; paired delta +131,358,[95,569,170,883] | Mean fails1.25x; p95 within1.50x |
| Revocation mean tokens | 1.051x known subsets | Inconclusive: one candidate cost unknown |
| Quiet mean tokens | 0.810x known subsets | Inconclusive: one Bi cost unknown |
| Quiet reply p95 | 2.806s vs2.480s,1.131x | Fails1.10x; no extra native turn in any quiet arm |

The defer baseline usually fails to resume, so more consumption also buys completion. That explains the tradeoff but does not silently waive the fixed budget. Five quiet samples and uncontrolled cache/machine load are not sufficient to assign the p95 difference causally to code. No #2053 exception transfers.

Canonical read-only audit found four early stops with remaining observed/snoozed work: C chatter3(12), C chatter8(1original), C correction5(8including original), Bi correction3(14). Frozen usage is retained; later cost/duplicates are unknown, not zero. Those Bots were not reactivated to repair the experiment. The final audit covered120arms with0collection errors.

All-attempt known Host cost subtotal is$0.710335212: C$0.278186058, Bi$0.249835824, B0$0.182313330. Five failed model attempts have unknown Host totals: B0chatter6, Cchatter8, B0defer5, Crevoke3, Biquiet8. Completed native responses independently total$0.739629630; never add that subtotal to Host usage.120auxiliary request records, provider-unreported retries and this assistant's review cost remain unknown. Partial known cost per mechanical success is C$0.007320686/Bi$0.016655722/B0$0.012154222; these are not complete unit costs. Raw five token buckets, paired intervals and coverage are in analysis-v2.json.

Bounded review stays at two automatic rechecks. Crevoke3 makes one premature override request, which is refused before authorization, then one exhausted-budget request refused after revocation: two model requests are not two authorized commits. All invalid calls remain in the cost ledger. No permission fallback was observed.

Current source `d7756295641bf5ccedda228e903c23bf48f76057` is later than this cohort: it protects original work during exhausted drop, supplies continuation guidance for no-ID/FYI-only drops and requires canonical settlement in the future evaluator. Full CI passed, but its registered two-pair native diagnostics remain pending. No new formal cohort, merge, closure or deployment is justified by this rejected v2 run. Preserve v1/v2 separately; do not pool or replace failures.

The offline index contains all40comparisons with Bi/B0 selection, complete actual histories, native records and direct assessments. Browser QA checked80desktop views and the390px layout; message counts and aligned cards passed, console empty. This verifies the evidence viewer, not current runtime behavior.
