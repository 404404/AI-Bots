const marker='〔已清除场景：正文仅保留在授权私有评审记录中；此公开副本保留时间、作者与消息 ID〕';
const pick=(x,keys)=>Object.fromEntries(keys.filter(k=>x?.[k]!==undefined).map(k=>[k,structuredClone(x[k])]));
const msg=m=>({...pick(m,['id','at','author','channelRevision','contentPurge','historyEvidence']),body:marker});
const tools=t=>({...pick(t,['seq','at','finishedAt','callId','name','isError']),argumentsOmitted:true,resultOmitted:true,redaction:'purged-episode-payload'});
const terminal=v=>(v??[]).map(e=>({...pick(e,['sessionId','seq','at','tool','status','code','draftId','messageId']),payloadRedacted:true}));
export function redactPublicPurge({report,native,assessment,responsibility}){
 const out=structuredClone({report,native,assessment,responsibility}),redactions=[];
 for(const p of out.report.pairs){
  for(const [arm,r]of Object.entries(p.runs)){
   if(!r.purge)continue;
   const safe=pick(r,['family','index','variant','channels','botDms','bots','group','startedAt','finishedAt','sourceStartedAt','episodeSourceStartedAt','recoveryRequestedAt','faultAppliedAt','outcomeCutoffAt','observedStopAt','sourceMessageId','settled','censored','exposure','valid','goal','responseCount','firstReplyMs','recoveryReplyMs','episodeMs','costEstimateUSD','usage','preludeUsage','preRestartUsage','postRestartUsage','postPreludeUsage','recoveryUsage','responsibility','faultKind']);
   safe.teardown=(r.teardown??[]).map(t=>({...pick(t,['slug','paused','stopped']),...(t.error?{error:'Purged-episode teardown error; details retained privately'}:{})}));
   safe.purge={sourceEventIds:r.purge.sourceEventIds,authorized:true,endedGroupBeforePurge:!!r.endedGroup};
   safe.publicRedaction={reason:'canonical-source-purge',scope:'All episode message bodies and model Tool/visible payloads removed conservatively, including before/after histories and copied draft text. Full authorized private records remain separate; this public projection is not complete plaintext.',privateSourceFile:'formal.json'};
   safe.transcript=Object.fromEntries(Object.entries(r.transcript??{}).map(([id,ms])=>[id,ms.map(msg)]));
   safe.fault=pick(r.fault,['phase','at','callId','sessionId','match','action']);
   if(r.error)safe.error={message:'Purged-episode error; details retained privately',code:r.error.cause??'unknown'};
   safe.providerUsage=(r.providerUsage??[]).map(s=>({...pick(s,['sessionId','botSlug','attempts','auxiliary','modelSteps','route']),toolCalls:(s.toolCalls??[]).map(tools)}));
   p.runs[arm]=safe;
   for(const s of out.native.sessions.filter(s=>s.pairId===p.id&&s.arm===arm)){
    s.assistantText=(s.assistantText??[]).map(t=>({...pick(t,['seq','at','turn','step','outsideWindow']),text:[marker]}));
    for(const key of ['extraTools','lateTools'])s[key]=(s[key]??[]).map(t=>({...pick(t,['seq','at','type']),data:{name:t.data?.name,callId:t.data?.callId??t.data?.message?.toolCallId,payloadRedacted:true}}));
    s.attempts=(s.attempts??[]).map(t=>({...pick(t,['seq','at','turn','step','usage']),finishes:(t.finishes??[]).map(f=>({at:f.at,kind:f.reason?.kind,failureCode:f.reason?.failure?.code,payloadRedacted:true}))}));
    s.publicRedaction=safe.publicRedaction;
    const allowed=new Set(['pairId','arm','cutoff','accountingCutoff','botSlug','sessionId','newOverrideToolPresent','assistantText','attempts','extraTools','lateCompleted','lateTools','publicRedaction']);for(const k of Object.keys(s))if(!allowed.has(k))delete s[k];
   }
   const review=out.assessment?.reviews?.find(x=>x.pairId===p.id);
   const terminalEvidence=Object.fromEntries(['candidate','baseline','original'].filter(side=>review?.[side]?.terminalEvidence).map(side=>[side,terminal(review[side].terminalEvidence)]));
   if(review){if(review.summaryZh)review.summaryZh={baseline:'本组包含已清除来源；公开副本保留实际判分与结果，具体正文和评审叙述保留在授权私有记录。',original:'本组包含已清除来源；公开副本保留实际判分与结果，具体正文和评审叙述保留在授权私有记录。'};for(const side of ['candidate','baseline','original'])if(review[side]){const v=review[side];review[side]={...pick(v,['sessionId','scores','scope','recoveryJudgment','taskSuccess','unauthorizedOutput','duplicateCommit','contentLeak','evidenceIds']),reason:'This pair contains purged source content. Narrative details remain in the authorized private assessment; public scores and outcome flags preserve the actual judgment.'};}for(const k of ['reason','readEvidence','qualification'])if(review[k])review[k]='Purged-pair prose retained privately; use event IDs and structured judgments.';}
   for(const [side,evidence]of Object.entries(terminalEvidence))review[side].terminalEvidence=evidence;
   redactions.push({pairId:p.id,arm,sourceEventIds:r.purge.sourceEventIds,bodyCount:Object.values(r.transcript??{}).reduce((n,ms)=>n+ms.length,0),toolPayloadCount:(r.providerUsage??[]).reduce((n,s)=>n+(s.toolCalls??[]).length,0)});
  }
 }
 return {...out,redactions};
}
