---
title: "群聊发送复核 · PR #2066"
subtitle: 纠正后复核；取消后停下；显式完成 Inbox
lang: zh
template: doc
theme: paper
PR: https://github.com/BotHarness/DeepSeekBot/pull/2066
base: 0b19f8871da0bb22669583c51350404af73d4ec4
evalBaseline: 73056fc59dcac42c3fd7e6cb1586f6c1c4e37157
head: 4ff5b6b1460dfe6ddac2fd7a56ee3e2f6bb30d2a
generated: 2026-10-18
---
这份说明绑定上面的提交。第四轮使用该提交的干净构建。
评估保留所有失败、未知用量与前几轮结果，Human 验收仍待完成。

## A 发送前复核
```timeline v
01 | 完整观察 | Host 记录实际交付的内容范围与指纹。
02 | 原子检查 | 与原有正式消息 append 共用事务。
03 | held | 有变化时保留草稿，返回有界新增上下文。
04 | 一次决定 | Bot 修改、原文重交或静默 drop。
05 | 显式完成 | 成功后才执行 Bot 指定的 Inbox 结清。
```
内容不全时仍须读取。再次变化、过期或 Host 重启时停止自动提交。

## B 谁拥有事实
| 事实 | 所有者与边界 |
|---|---|
| 正式消息 | 原 Channel append 事务与 Source Event |
| 观察依据 | Host 句柄绑定 Bot、Session、Group 与完整内容 |
| 待复核草稿 | GroupSendReview 持久记录；沿用内容 purge |
| 新增内容 | 复用 channel_read 投影，完整结果上限 12000 字符 |
| 完成责任 | 原 Inbox owner；显式选择，发送不等于结清 |
| Human 判断 | 完整左右历史；先选，再看模型与成本 |

[发送复核 owner](https://github.com/BotHarness/DeepSeekBot/blob/4ff5b6b1460dfe6ddac2fd7a56ee3e2f6bb30d2a/packages/core/src/channels/send-review.ts) · [工具与显式结清](https://github.com/BotHarness/DeepSeekBot/blob/4ff5b6b1460dfe6ddac2fd7a56ee3e2f6bb30d2a/packages/core/src/runtime/dsh-bot-agent-adapter.ts)

## C 本次修正的边界
| 路径 | 行为 |
|---|---|
| 发送或 drop 成功 | 仅结清明确列出的完成事项 |
| 未传结清参数 | 返回 not-requested，提示本轮完成显式收尾 |
| 结清失败但发送成功 | 保留 messageId；修复结清，不能再次发送 |
| drop 未传群 ID | 使用当前入站群；直接 CLI 必须传群 ID |
| 发起任务的群已撤权 | 阻止本轮转去其他 Channel 继续回复 |
| 后续独立 DM | 仍可正常交互，已有回归覆盖 |

取消由模型理解，Host 不做关键词分类。
通用跨群预览竞争、外部 IM 和后续 slices 尚未获本轮证明。

## D 固定第四轮数据
四类各十对，80 个 episode，不补跑替换失败样本。
双方使用同一官方 DeepSeek 路由、冻结价格与原始预算。

| 场景 | 机械目标：基线 → 新版 | 成对 token 变化 |
|---|---|---|
| correction | 0/10 → 10/10 | -5.98%（10 对） |
| quiet | 10/10 → 10/10 | -30.88%（8 对） |
| unrelated | 10/10 → 10/10 | -3.05%（10 对） |
| cancel-or-revoke | 5/10 → 10/10 | -18.94%（9 对） |

纠正预算为 token +25%、回复 p95 +50%。
安静预算为 token +5%、回复 p95 +10%；无关旁话为 token +25%。

第四轮安静回复 p95 为 19.07 秒，基线为 6.18 秒。
增幅 208.39%，未通过延迟预算；尾部样本保留，原因未知。

纠正 token 降低 5.98%，已知成对美元成本却增加 5.91%。
安静 token 降低 30.88%，已知成对美元成本只降低 1.73%。
token 与美元各自计量；缓存比例会影响价格。

沉默没有回复延迟。缺失用量不算零，精确分母与区间见报告。
小样本、供应商缓存和共享机器限制结果的外推范围。

## E 为什么保留失败轮
第三轮安静 token 增加 11.95%，未通过 5% 预算。
其纠正回复 p95 也超标；正确回答不能抵消等待成本。
纠正第八对正确说明旧时间已作废，却触发正则误判。
原始 goal 保持不变，另记人工解释。

第三轮包带旧版本标记。代码结构核对一致，限制仍明确保留。
第四轮先提交再构建。两轮共 160 次双顺序模型判断完整保存。
模型结论需与完整历史核对，不能代替 Human 接受。

## F 审查与交付
72 项相关测试、根类型检查、lint、相关格式和 build 通过。
真实 CLI 与 Web 历史证据已留存；不宣称最新全套 CI 或手机验证。
第四轮已知评估成本为 USD 0.414383，另有未知计费。
包括历轮的已知累计为 USD 1.671376，不是完整账单。

schema96 使旧二进制无法直接打开新 Profile。
关闭开关可回退行为；二进制回退需要升级前备份或兼容迁移。
PR 保持草稿且与 main 冲突。#2054–2056 继续等待首票验收。
下载 ZIP 可直接选左、右、差不多或不好判断，无需逐项打分。
