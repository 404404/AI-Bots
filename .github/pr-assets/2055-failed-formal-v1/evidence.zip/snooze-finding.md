### Deferred-return defect found in the fixed cohort

Task: `codex/local/01a14906-16cc-7800-a569-b5c812c02eef`; claim remains active.

Direct reading is complete for the first 22 triplets. In `defer-1`, both Bi and the frozen candidate correctly dropped the draft and snoozed the unfinished request, but never resumed within the fixed observation window. A read-only canonical Admission probe confirms the awaited R4 update remained unobserved/pending, the original responsibility remained unresolved, and its snooze deadline was cleared.

The existing attention predicate counted any later Admission as an early return, including ordinary Group messages that did not wake the Bot. The timer then silently consumed the deadline. Commit `96c35f83e32c7b47d9e5d70f04ccfe70bb110efe` requires a later Admission to have actually been observed before it suppresses the deadline return. This reuses the existing Inbox timer and changes no wake policy or schema.

Validation: a minimal real-runtime regression failed before the fix (one turn instead of the required return turn), then 13 focused snooze/triage/attention tests passed. The final five snooze tests additionally check that genuinely observed updates still return early without a duplicate deadline turn. Typecheck, format and lint passed; the first lint attempt caught missing change-fragment provenance, now fixed. No real-model recovery pass is claimed yet.

The old cohort continues unchanged; these failures remain in its results. The corrected candidate is built in a separate QA checkout. PR remains draft pending real DSH correction/defer qualification and complete cost/history review. No deployment and no inherited latency exception.
