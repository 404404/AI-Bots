import pathlib,re,sys,json
p=pathlib.Path(sys.argv[1]);s=p.read_text(encoding='utf-8');aliases={}
# Lossless readability substitutions: identities remain distinct; full IDs in sibling map.
pat=r'(?:bot-channel-post-bot-[a-f0-9]+|bot-[a-f0-9]{20,}|botharness-[a-f0-9-]{36}|[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}|group-llm-e2e-busy-[a-z0-9-]+)'
def sub(m):
 v=m.group();aliases.setdefault(v,'@'+str(len(aliases)+1));return aliases[v]
s=re.sub(pat,sub,s)
# Intern repeated exact long JSON strings; never delete a novel field or message.
counts={}
for match in re.finditer(r'"(?:[^"\\]|\\.)*"',s):
 x=match.group()
 if len(x)>16 and not s[match.end():].lstrip().startswith(':'):counts[x]=counts.get(x,0)+1
legend={}
for x,n in counts.items():
 if n>1:
  key='S'+str(len(legend)+1);legend[key]=json.loads(x);s=s.replace(x,json.dumps('$'+key))
out=p.with_name(p.stem+'-compact.txt');out.write_text('Repeated exact strings: '+json.dumps(legend,ensure_ascii=False)+'\n'+s,encoding='utf-8');p.with_name(p.stem+'-identities.json').write_text(json.dumps({v:k for k,v in aliases.items()},indent=2),encoding='utf-8')
print(out)
