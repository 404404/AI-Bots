import {readFileSync,writeFileSync} from 'node:fs';
import {readJsonSnapshot} from './read-report.mjs';
import {readEpisodeResponsibility} from '../../../scripts/e2e-group-responsibility.mjs';
const root='.humanlayer/tasks/2055/',report=readJsonSnapshot(root+'formal-v2.json').value;
const paths={candidate:'.humanlayer/verify/busy-review-2055/instance.json',baseline:'../qa-2055-bi/.humanlayer/verify/busy-review-2055-bi/instance.json',original:'../qa-2053-baseline/.humanlayer/verify/send-review-2053-ingest-base/instance.json'};
const audit={observedAt:new Date().toISOString(),finishedCohort:!!report.finishedAt,scope:'Read-only post-teardown canonical responsibility, finished arms only. Does not rewrite frozen outcomes or costs. Early settled episodes with pending work leave subsequent costs/duplicates unobserved, not zero.',rows:[]};
for(const [arm,path]of Object.entries(paths)){
 const instance=JSON.parse(readFileSync(path));
 for(const pair of report.pairs){
  const run=pair.runs[arm];if(!run?.finishedAt)continue;
  const item={pairId:pair.id,arm,goal:run.goal,settled:run.settled,censored:run.censored,outcomeCutoffAt:run.outcomeCutoffAt};audit.rows.push(item);
  try{
   const requests=run.transcript?.[run.group]?.filter(m=>m.author.kind==='human'&&m.body.includes('请按已确认事实发一条简明会议通知'))??[];
   if(requests.length!==1)throw Error('No unique original request in retained actual history');
   item.result=readEpisodeResponsibility(instance,{botSlugs:[run.bots.aura,run.bots.atlas],channelId:run.group,messageId:requests[0].id});
   item.earlyStopWithOpenResponsibility=run.settled===true&&!item.result.complete;
  }catch(error){item.error=error.message;item.earlyStopWithOpenResponsibility=null;}
 }
}
const body=JSON.stringify(audit,null,2)+'\n';writeFileSync(root+'formal-v2-responsibility.json',body);writeFileSync(root+'formal-v2-responsibility-'+Date.now()+'.json',body);
console.log(JSON.stringify({arms:audit.rows.length,errors:audit.rows.filter(r=>r.error).length,earlyStops:audit.rows.filter(r=>r.earlyStopWithOpenResponsibility).map(r=>({pairId:r.pairId,arm:r.arm,pending:r.result.pendingCount}))}));
