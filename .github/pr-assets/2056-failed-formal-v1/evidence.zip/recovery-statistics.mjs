import {pairedInterval} from '../../../scripts/group-send-review-report.mjs';

export const finite=x=>typeof x==='number'&&Number.isFinite(x);
export const mean=xs=>xs.length?xs.reduce((n,x)=>n+x,0)/xs.length:null;
export function statistics(values){
 const xs=values.filter(finite).sort((a,b)=>a-b);
 return {n:xs.length,unknown:values.length-xs.length,mean:mean(xs),median:xs.length?xs[Math.ceil(xs.length*.5)-1]:null,p95:xs.length?xs[Math.ceil(xs.length*.95)-1]:null};
}
export function paired(pairs,arm,read,exposedOnly=false){
 const selected=pairs.filter(p=>!exposedOnly||(p.runs[arm]?.exposure===true&&p.runs.candidate?.exposure===true));
 const values=selected.map(p=>[read(p.runs[arm]??{}),read(p.runs.candidate??{})]).filter(xs=>xs.every(finite));
 const deltas=values.map(([b,c])=>c-b);
 return {eligible:selected.length,n:values.length,unknownPairs:selected.length-values.length,meanDelta:mean(deltas),ci95:pairedInterval(deltas,2056)};
}
// Unknown or censored whole-episode cost cannot pass on a cheap finite subset.
export function budget(candidate,baseline,limit,{complete,fullyAccounted}){
 const ratio=finite(candidate)&&finite(baseline)&&baseline>0?candidate/baseline:null;
 return {ratio,limit,knownSubsetExceeds:ratio===null?null:ratio>limit,status:!complete||!fullyAccounted||ratio===null?'inconclusive':ratio<=limit?'pass':'fail'};
}
export function turnCount(run,native){
 const sessions=native.sessions.filter(s=>Object.values(run.bots??{}).includes(s.botSlug));
 if(!sessions.length||!run.providerUsage?.length)return null;
 const turns=new Set();
 for(const s of sessions){
  const usage=run.providerUsage.find(p=>p.sessionId===s.sessionId);
  for(const e of [...s.assistantText,...s.attempts,...(usage?.modelSteps??[])]){
   if(Number.isInteger(e.turn))turns.add(s.sessionId+':'+e.turn);
  }
 }
 return turns.size||null;
}

export function cohortProblems(report,assessment){
 const families=['held-restart','response-loss','refusal','quiet'];
 const expected=families.flatMap(f=>Array.from({length:10},(_,i)=>`${f}-${i+1}`));
 const errors=[];
 if(!report.finishedAt)errors.push('cohort-unfinished');
 if(report.pairs.length!==40||new Set(report.pairs.map(p=>p.id)).size!==40||expected.some(id=>!report.pairs.some(p=>p.id===id)))errors.push('fixed-pair-identities-incomplete');
 for(const p of report.pairs){
  if(!expected.includes(p.id)||!p.id.startsWith(p.family+'-'))errors.push(`unexpected-pair:${p.id}`);
  for(const arm of ['candidate','baseline','original'])if(!p.runs[arm]?.finishedAt)errors.push(`unfinished-arm:${p.id}:${arm}`);
 }
 if(assessment.reviews.length!==40||new Set(assessment.reviews.map(r=>r.pairId)).size!==40)errors.push('review-count-or-duplicates');
 for(const id of expected){
  const r=assessment.reviews.find(x=>x.pairId===id);
  if(r?.status!=='all-three-arms-complete-records-read'){errors.push(`review-incomplete:${id}`);continue;}
  for(const arm of ['candidate','baseline','original']){
   const run=report.pairs.find(p=>p.id===id)?.runs[arm];
   // A started model step is not an answer. Preserve its unknown usage, but do not
   // invent quality scores when interruption preceded all responses and Tools.
   const notObservable=r[arm]?.ratingScope==='not-observable-prelude-interruption'&&run?.error&&run.exposure===false&&!run.sourceStartedAt&&run.providerUsage?.every(s=>!s.attempts?.length&&!s.responses?.length&&!s.toolCalls?.length)&&assessment.dimensions.every(d=>r[arm]?.scores?.[d]===null)&&!!r[arm]?.reason&&
     (arm==='candidate'?r.candidateVsBaseline==='insufficient'&&r.candidateVsOriginal==='insufficient':r[arm==='baseline'?'candidateVsBaseline':'candidateVsOriginal']==='insufficient');
   if(!notObservable&&assessment.dimensions.some(d=>!Number.isInteger(r[arm]?.scores?.[d])||r[arm].scores[d]<1||r[arm].scores[d]>5))errors.push(`scores-incomplete:${id}:${arm}`);
   if(['taskSuccess','unauthorizedOutput','contentLeak','duplicateCommit'].some(k=>typeof r[arm]?.[k]!=='boolean'))errors.push(`judgments-incomplete:${id}:${arm}`);
  }
  for(const key of ['candidateVsBaseline','candidateVsOriginal'])if(!['win','loss','tie','insufficient'].includes(r[key]))errors.push(`verdict-incomplete:${id}:${key}`);
 }
 return errors;
}
