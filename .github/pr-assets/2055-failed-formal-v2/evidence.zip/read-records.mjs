import { readFileSync } from 'node:fs';
import { readJsonSnapshot } from './read-report.mjs';
const root = '.humanlayer/tasks/2055/';
const name = process.argv[2] ?? 'formal-v1.json';
const report = readJsonSnapshot(root + name).value;
const native = JSON.parse(readFileSync(root + name.replace('.json', '-native.json'), 'utf8'));
const first = Number(process.argv[3] ?? 0), last = Number(process.argv[4] ?? first + 1);
const parse = x => { try { return typeof x === 'string' ? JSON.parse(x) : x; } catch { return x; } };
for (const pair of report.pairs.slice(first, last)) {
  console.log('PAIR', pair.id);
  for (const [arm, run] of Object.entries(pair.runs)) {
    if (!run.finishedAt) { console.log(arm, 'INCOMPLETE'); continue; }
    console.log('ARM', arm, JSON.stringify(Object.fromEntries(['valid','goal','error','censored','windowHit','sourceStartedAt','resumeAt','conditionAt','revokedAt','firstReplyMs','episodeMs','costEstimateUSD'].map(k=>[k,run[k]]))));
    const messages = new Map(Object.values(run.transcript ?? {}).flat().map(m => [m.id,m]));
    for (const [channel, items] of Object.entries(run.transcript ?? {})) {
      console.log('CHANNEL', channel);
      for (const m of items) console.log(JSON.stringify({id:m.id,at:m.at,author:m.author,body:m.body,...(m.attachments?{attachments:m.attachments}:{})}));
    }
    const project = value => {
      if (Array.isArray(value)) return value.map(project);
      if (value && typeof value === 'object') {
        if (value.message?.id && messages.get(value.message.id)?.body === value.message.body) {
          const { body, ...metadata } = value.message;
          const known=messages.get(value.message.id);
          // Reconstruct exact already-printed fields from canonical history; retain all novel metadata.
          for(const key of ['id','at','author','attachments']) if(JSON.stringify(metadata[key])===JSON.stringify(known[key])) delete metadata[key];
          return {...value,message:{historyRef:value.message.id,...metadata}};
        }
        return Object.fromEntries(Object.entries(value).map(([k,v])=>[k,k==='content'&&typeof v==='string'?project(parse(v)):project(v)]));
      }
      return value;
    };
    for (const session of run.providerUsage ?? []) {
      console.log('SESSION', session.sessionId, 'bot', session.botSlug);
      for (const tool of session.toolCalls) console.log('TOOL', JSON.stringify({seq:tool.seq,at:tool.at,finishedAt:tool.finishedAt,name:tool.name,args:parse(tool.arguments),isError:tool.isError,result:project(parse(tool.result))}));
      const supplement = native.sessions.find(s=>s.sessionId===session.sessionId);
      console.log('VISIBLE_AND_FAILURES',JSON.stringify(supplement));
    }
  }
}
