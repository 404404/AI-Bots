### Bounded corrected-candidate diagnostic (excluded from acceptance statistics)

- Task: `codex/local/01a14906-16cc-7800-a569-b5c812c02eef`.
- Candidate: `96c35f83e32c7b47d9e5d70f04ccfe70bb110efe`; independent built Host. Includes the atomic override check, same-turn exhausted-drop fence, and the observed-Admission snooze-return correction.
- Bi: accepted `390630e0dc81b0e776758bc420c1622b2ad51981`, unchanged isolated Host.
- Reuse `scripts/e2e-group-busy-review.mjs` and frozen `2055-busy-v1` inputs, DeepSeek official flash route, effort off, pricing and whole-episode accounting. Two correction pairs followed by two defer pairs, alternating arm order inside each family. No replacement attempts; no B0 in this diagnostic.
- Begin only after the current `formal-v1` cohort has finished, so it receives no added model concurrency. This diagnostic is not pooled into either formal cohort.
- Correction: read all records to check that a late correction blocks obsolete submission, unfinished work stays open, and actual deferred recovery uses fresh 11:00/B-204 facts. Report any missed specific race separately.
- Defer: drop, snooze to the specified time, remain quiet before that time, actually wake/read the unmentioned R4 update, then publish exactly one complete R4 notice. Do not count a scheduled promise as completion, and do not excuse early publication after rounding a timestamp.
- Read actual complete DSH Session/Tool/Group/DM records directly with the current assistant, no external judge. Retain all failed attempts and unknown costs. Diagnostic completion does not authorize merger; formal revised qualification follows only after its findings are addressed.
