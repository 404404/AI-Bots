from pathlib import Path
import hashlib,json,zipfile

task=Path('.humanlayer/tasks/2054')
out=task/'offline-review'
out.mkdir(exist_ok=True)
for label,name,other in [('bi','index.html','original.html'),('b0','original.html','index.html')]:
 html=(task/f'review-{label}.html').read_text(encoding='utf8')
 html=html.replace('const humanReviewComplete=', "for(const e of data.assistantReview?.entries||[])if(e.requiredHumanReview)data.required[e.pairId]=[...(data.required[e.pairId]||[]),'post-judge full-history assistant audit'];const humanReviewComplete=")
 html=html.replace("data.report.protocolHash+'-'+data.report.candidate;let saved",f"data.report.protocolHash+'-'+data.report.candidate+'-offline-2054-{label}-v1';let saved")
 other_label='b0' if label=='bi' else 'bi'
 html=html.replace('let index=0,lastChoice=null;',f"function otherReview(id){{try{{const r=JSON.parse(localStorage.getItem(key.replace('-offline-2054-{label}-v1','-offline-2054-{other_label}-v1'))||'{{}}')[id];return r?{{comparison:'{other_label}',at:r.at,revealedAt:r.revealedAt,winner:r.winner}}:null}}catch{{return null}}}};let index=0,lastChoice=null;")
 html=html.replace('saved[p.id]={pairId:p.id,reviewMode:', "saved[p.id]={pairId:p.id,otherComparisonExposureCoverage:'same-origin storage only; absence is unknown, especially across file URLs',otherComparisonReview:otherReview(p.id),reviewMode:")
 lower="function nativeLower(r){const a=(r.providerUsage||[]).flatMap(s=>s.attempts||[]),b=['inputTokens','outputTokens','cacheReadTokens','cacheWriteTokens','totalTokens'];if(!a.length||a.some(x=>b.some(k=>typeof x.usage?.[k]!=='number')))return '已知完成响应下界：unknown';const t=Object.fromEntries(b.map(k=>[k,a.reduce((n,x)=>n+x.usage[k],0)])),p=data.report.protocol.prices.perMillion;const cost=t.cacheWriteTokens===0?(t.inputTokens*p.inputTokens+t.outputTokens*p.outputTokens+t.cacheReadTokens*p.cacheReadTokens)/1e6:null;return '已知完成响应：'+t.totalTokens+' tokens · 费用下界 '+(cost===null?'unknown':'$'+cost.toFixed(6))+'（不含未知失败／辅助请求，不等于完整总量）'};"
 html=html.replace('function drawReveal(){',lower+'function drawReveal(){')
 html=html.replace("r.costEstimateUSD.toFixed(6))+'</p>'", "r.costEstimateUSD.toFixed(6))+'</p><p class=muted>'+nativeLower(r)+'</p>'")
 html=html.replace('<h2>你更喜欢哪一段对话？</h2>',f'<p class="muted">对照组 {"A" if label=="bi" else "B"} · 40 组完整历史 · <a href="{other}">切换另一组对照</a>（各自保存选择）</p><h2>你更喜欢哪一段对话？</h2>')
 html=html.replace('<div id="history" class="cols">','<p id="storage-warning" role="alert" class="notice" hidden>此浏览器不允许保存。关闭前请导出或复制结果文本。</p><details id="export-backup"><summary>结果文本（下载失败时复制这里）</summary><p class="muted">全选复制后发回即可，与下载文件相同。</p><textarea id="export-text" readonly aria-label="评审结果文本" style="width:100%;height:180px;padding:12px;box-sizing:border-box"></textarea><button id="select-export" class="quiet">全选结果文本</button></details><div id="history" class="cols">')
 start=html.index("q('export').onclick=")
 end=html.index(';show();',start)+len(';show();')
 payload="{humanReviewProtocol:'pairwise-preference-v2',reviewSessionId:'offline-2054-"+label+"-v1',comparison:'"+label+"',protocolHash:data.report.protocolHash,candidate:data.report.candidate,reportHash:data.sourceReportHash,ratings:saved,unreviewed:data.report.pairs.filter(p=>!humanReviewComplete(saved[p.id])).map(p=>p.id),requiredPairIds:Object.keys(data.required)}"
 html=html[:start]+"function updateExportText(){q('export-text').value=JSON.stringify("+payload+",null,2)};q('select-export').onclick=()=>{q('export-text').focus();q('export-text').select()};q('export').onclick=()=>{updateExportText();q('export-backup').open=true;const a=document.createElement('a');const url=URL.createObjectURL(new Blob([q('export-text').value],{type:'application/json'}));a.href=url;a.download='2054-human-review-"+label+".json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);q('feedback').textContent='已尝试下载。若没有文件，请复制展开的结果文本。'};q('storage-warning').hidden=persist();show();"+html[end:]
 html=html.replace("function show(){const p=pair();", "function show(){updateExportText();const p=pair();")
 html=html.replace("persist();drawReveal()", "persist();updateExportText();drawReveal()")
 (out/name).write_text(html,encoding='utf8')
(out/'开始阅读.txt').write_text('''#2054 同伴让话 · 离线完整历史评审

1. 完整解压 ZIP，用 Chrome 或 Edge 打开 index.html。
2. 两张卡片分别展示完整群聊；展开卡片底部可看之前的私聊准备轮。
   选左、右、两边差不多或不好判断。可跳过、撤销、返回；不需要逐维评分。
3. 先独立选择，再用「查看上次选择的 token 与成本」揭盲。
4. 完成后点「导出选择」，把 JSON 文件发回。
   下载失败时，展开「结果文本」，点「全选结果文本」，复制发回。

本轮有40组三臂对话：新版分别与上一片已接受实现、最初基线比较。
两页各40组，共享同一批新版对话；并非80次新版运行。页面顶部可切换。
每页独立保存选择，文件名分别为2054-human-review-bi.json与2054-human-review-b0.json。
新版历史会重复出现，第二页可能受先前阅读或揭盲影响。浏览器允许两页共享存储时会保留另一页已选/揭盲的情况；file 页面可能隔离存储，因此未记录不等于从未看过。复评时请告知是否已经看过另一页。
带「必看」标记的样本包括固定抽样、失败、顺序分歧和预算异常；其他历史也全部可查。
未选不自动算平局。「差不多」表示体验相近，不表示接受成本或延迟超限。

请保持浏览器和解压位置不变，不用无痕模式。建议中途导出备份。
页面完全离线，不调用模型、不增加费用、不上传数据。Host关闭后仍可浏览。
工具与状态证据、LLM原始评分及助手复核保留在揭盲区。未知用量保留unknown。
Human体验判断不等于批准合并或部署。
''',encoding='utf-8-sig')
manifest={'issue':2054,'reviewSessionId':'offline-2054-v1','comparisons':{},'files':{}}
for label,name in [('bi','index.html'),('b0','original.html')]:
 html=(out/name).read_text(encoding='utf8')
 payloadtext=html.split('<script type="application/json" id="data">',1)[1].split('</script>',1)[0]
 data=json.loads(payloadtext)
 manifest['comparisons'][label]={'pairs':len(data['report']['pairs']),'candidate':data['report']['candidate'],'protocolHash':data['report']['protocolHash'],'sourceReportHash':data['sourceReportHash'],'payloadSha256':hashlib.sha256(payloadtext.encode()).hexdigest()}
for p in out.iterdir():
 if p.name!='manifest.json':manifest['files'][p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
path=task/'2054-human-review.zip'
with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in out.iterdir():z.write(p,p.name)
with zipfile.ZipFile(path) as z:assert z.testzip() is None
print(json.dumps({'zip':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}))
