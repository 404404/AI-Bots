import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {summarize,auditRun,pairedInterval,humanReviewSet} from '../../../scripts/group-send-review-report.mjs';
import {price,taskOutputs} from '../../../scripts/e2e-group-send-review.mjs';
const root='.humanlayer/tasks/2054/';
const read=p=>JSON.parse(readFileSync(root+p,'utf8'));
const write=(p,x)=>writeFileSync(root+p,JSON.stringify(x,null,2)+'\n');
const hash=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
const finite=x=>typeof x==='number'&&Number.isFinite(x);
const sum=x=>x.reduce((a,b)=>a+b,0);
const mean=x=>x.length?sum(x)/x.length:null;
const quantile=(x,p)=>x.length?x.slice().sort((a,b)=>a-b)[Math.ceil(p*x.length)-1]:null;
const ratio=(a,b)=>finite(a)&&finite(b)&&b!==0?a/b:null;
const stats=x=>({n:x.length,mean:mean(x),median:quantile(x,.5),p95:quantile(x,.95)});
const operationalSuccess=r=>r.goal&&r.settled&&r.usage?.settled&&!r.censored&&!r.error&&!r.routeMismatch;
const mechanism=r=>{
 const calls=(r.providerUsage??[]).filter(s=>s.botSlug===r.bots?.aura).flatMap(s=>s.toolCalls??[]).map(c=>{try{return {...c,parsed:JSON.parse(c.result)}}catch{return c}});
 return {aHeld:calls.filter(c=>c.name==='channel_send'&&c.parsed?.status==='held').length,aYield:calls.filter(c=>c.parsed?.reason==='explicit-peer-yield').length,aObservedPeer:calls.some(c=>c.parsed?.review?.observedMessageIds?.includes(r.peerMessageId)||(c.name==='channel_read'&&c.parsed?.messages?.some(m=>(m.message?.id??m.id)===r.peerMessageId))),aInboxResolveCalls:calls.filter(c=>c.name==='inbox_resolve').length};
};
const source=read('formal-triplets.json');
if(!source.finishedAt)throw Error('Do not analyze a partial formal run');
const supplement=read('failed-attempts.json');
const enriched=(run,arm,pairId)=>({...run,providerUsage:(run.providerUsage??[]).map(s=>({...s,failedAttempts:supplement.attempts.filter(a=>a.report==='formal-triplets.json'&&a.pairId===pairId&&a.arm===arm&&a.sessionId===s.sessionId)}))});
const buckets=['inputTokens','outputTokens','cacheReadTokens','cacheWriteTokens','totalTokens'];
const all=source.pairs.flatMap(p=>Object.entries(p.runs).map(([arm,r])=>({pairId:p.id,arm,run:r})));
const ledgerRuns=items=>({episodes:items.length,hostKnownCostUSD:sum(items.map(x=>x.run.costEstimateUSD).filter(finite)),hostUnknownCostEpisodes:items.filter(x=>!finite(x.run.costEstimateUSD)).map(x=>[x.pairId,x.arm]),nativeCompletedKnownCostUSD:sum(items.map(x=>price(auditRun(x.run).nativeKnownBuckets)).filter(finite)),nativeUnknownCostEpisodes:items.filter(x=>!finite(price(auditRun(x.run).nativeKnownBuckets))).map(x=>[x.pairId,x.arm]),nativeAuxiliaryUnknownRequests:sum(items.map(x=>auditRun(x.run).auxiliaryUnknownRequests)),providerUnreportedRetries:'unknown; no invoice attestation'});
const diagnostics=['diagnostic-redundant.json','diagnostic-redundant-v2.json','diagnostic-independent.json'].flatMap(file=>read(file).pairs.flatMap(p=>Object.entries(p.runs).map(([arm,run])=>({pairId:file+'/'+p.id,arm,run}))));
const ledger={sourceHash:hash(source),uniqueFormal:ledgerRuns(all),diagnostics:ledgerRuns(diagnostics),judges:{calls:0,knownCostUSD:0,unknownCostCalls:0},doubleCounting:'Bi/B0 pairwise reports share 40 candidate episodes; only the 120 original episodes enter this ledger. Native completed response estimates are an alternate reconciliation, never added to Host estimates.'};
const results={sourceHash:hash(source),candidate:source.candidate,comparisons:{},attemptIndex:all.map(({pairId,arm,run:r})=>({pairId,arm,valid:r.valid,goal:r.goal,window:r.windowHit,error:r.error,censored:r.censored,usageError:r.usageError,providerUsageError:r.providerUsageError,hostKnown:r.usage?.host,routeMismatch:r.routeMismatch,nativeAudit:auditRun(r),aMechanism:mechanism(r),group:r.group,startedAt:r.startedAt,finishedAt:r.finishedAt}))};
for(const [label,arm] of [['bi','baseline'],['b0','original']]){
 const report={...source,sourceTripletsHash:hash(source),nativeAttemptSupplementHash:hash(supplement),supplementScope:supplement.scope,comparison:{label,baselineSHA:arm==='baseline'?source.protocol.baseline:source.protocol.originalBaseline,sharedCandidate:true},pairs:source.pairs.map(p=>({...p,runs:{baseline:enriched(p.runs[arm],arm,p.id),candidate:enriched(p.runs.candidate,'candidate',p.id)}}))};
 write('comparison-'+label+'.json',report);
 const judged=existsSync(root+'judge-'+label+'.json')?read('judge-'+label+'.json'):undefined;
 if(judged){ledger.judges.calls+=judged.rounds.length;ledger.judges.knownCostUSD+=sum(judged.rounds.map(r=>r.costEstimateUSD).filter(finite));ledger.judges.unknownCostCalls+=judged.rounds.filter(r=>!finite(r.costEstimateUSD)).length;}
 const rows=summarize(report,judged).map(row=>{
  const pairs=report.pairs.filter(p=>p.family===row.family),family=row.family;
  const metric={};
  for(const arm of ['baseline','candidate']){
   const runs=pairs.map(p=>p.runs[arm]);
   metric[arm]={observedGoalRate:runs.filter(r=>r.goal).length/runs.length,validGoalRate:runs.filter(r=>r.valid&&r.goal).length/runs.length,replyCount:stats(runs.map(r=>taskOutputs(r).length)),humanTargetMessages:stats(runs.map(r=>(r.transcript?.[r.group]??[]).filter(m=>m.author.kind==='human').length)),redundantReplyRate:family==='redundant'?runs.filter(r=>r.redundantReplyCount>0).length/runs.length:null,fyiAcknowledgmentRate:family==='fyi-control'?runs.filter(r=>r.fyiAcknowledgments>0).length/runs.length:null,controlLatency:stats(runs.map(r=>r.controlReplyMs).filter(finite)),buckets:Object.fromEntries(buckets.map(b=>[b,{...stats(runs.map(r=>r.usage?.host?.[b]).filter(finite)),unknown:runs.filter(r=>!finite(r.usage?.host?.[b])).length}]))};
   const audits=runs.map(auditRun);
   metric[arm].mechanism={completedResponses:stats(audits.map(a=>a.nativeCompletedResponses)),heldCalls:stats(audits.map(a=>a.held)),yieldCalls:stats(audits.map(a=>a.sends.filter(s=>s.reason==='explicit-peer-yield').length)),recordedFailedAttempts:stats(runs.map(r=>(r.providerUsage??[]).flatMap(s=>s.failedAttempts??[]).length)),nativeCompletedTokens:stats(audits.map(a=>a.nativeKnownBuckets.totalTokens).filter(finite)),preludeTokens:stats(runs.map(r=>r.preludeUsage?.host?.totalTokens).filter(finite)),postPreludeTokens:stats(runs.map(r=>r.postPreludeUsage?.totalTokens).filter(finite)),postPreludeCostUSD:stats(runs.map(r=>r.postPreludeCostEstimateUSD).filter(finite))};
   metric[arm].humanRepeatedInstructions={observedRetries:0,qualification:'Fixed script has no adaptive Human retries. The new question and explicit-request control are planned distinct requests; this does not measure whether real Humans would need to repeat themselves.'};
   metric[arm].aMechanism=runs.map(mechanism);
   metric[arm].operationalSuccessRate=runs.filter(operationalSuccess).length/runs.length;
  }
  const tokenBudget={redundant:1.15,independent:1.2,'new-question':1.1,'fyi-control':1.1}[family];
  const tokenRatio=ratio(row.variants.candidate.meanTokens,row.variants.baseline.meanTokens);
  const latencyRatio=ratio(row.variants.candidate.p95LatencyMs,row.variants.baseline.p95LatencyMs);
  const controlRatio=ratio(metric.candidate.controlLatency.p95,metric.baseline.controlLatency.p95);
  const reduction=family==='redundant'?(metric.baseline.redundantReplyRate===0?null:1-metric.candidate.redundantReplyRate/metric.baseline.redundantReplyRate):null;
  const controls=pairs.filter(p=>p.runs.baseline.valid&&p.runs.candidate.valid&&finite(p.runs.baseline.controlReplyMs)&&finite(p.runs.candidate.controlReplyMs));
  const controlDeltas=controls.map(p=>p.runs.candidate.controlReplyMs-p.runs.baseline.controlReplyMs);
  return {...row,behavior:metric,controlPaired:{n:controls.length,meanDeltaMs:mean(controlDeltas),ci95:pairedInterval(controlDeltas,2054)},gates:{token:{ratio:tokenRatio,limit:tokenBudget,status:row.variants.baseline.unknownTokens||row.variants.candidate.unknownTokens?'inconclusive':tokenRatio===null?'inconclusive':tokenRatio<=tokenBudget?'pass':'fail'},contributionP95:{ratio:latencyRatio,limit:1.3,status:latencyRatio===null||row.variants.candidate.missingReplyLatency||row.variants.baseline.missingReplyLatency||row.variants.candidate.censored||row.variants.baseline.censored?'inconclusive':latencyRatio<=1.3?'pass':'fail'},quietControlP95:family==='fyi-control'?{ratio:controlRatio,limit:1.1,status:controlRatio===null||controls.length<10?'inconclusive':controlRatio<=1.1?'pass':'fail'}:null,coverage:{observed:metric.candidate.observedGoalRate,limit:family==='independent'?.9:family==='fyi-control'?metric.baseline.observedGoalRate:.95,status:metric.candidate.observedGoalRate>=(family==='independent'?.9:family==='fyi-control'?metric.baseline.observedGoalRate:.95)?'pass':'fail'},redundancy:family==='redundant'?{reduction,status:reduction===null?'baseline-zero':reduction>=.5?'pass':'fail'}:null,fyi:family==='fyi-control'?{status:metric.candidate.fyiAcknowledgmentRate<metric.baseline.fyiAcknowledgmentRate?'pass':metric.candidate.fyiAcknowledgmentRate===metric.baseline.fyiAcknowledgmentRate?'tie':'fail'}:null,validPairs:row.validPairs,causalQualification:row.validPairs===10?'all planned pairs comparable':'inconclusive for planned full denominator; no replacement'}};
 });
 const stable=report.pairs.filter(p=>p.runs.baseline.valid&&p.runs.candidate.valid).map(p=>{const rr=judged?.rounds.filter(r=>r.pairId===p.id)??[];return rr.length===2&&rr.every(r=>!r.error&&!r.validation?.length)&&rr[0].mappedWinner===rr[1].mappedWinner?rr[0].mappedWinner:'unresolved';});
 const wins=stable.filter(x=>x==='candidate').length,losses=stable.filter(x=>x==='baseline').length,decisive=wins+losses;
 const rates=Object.fromEntries(['baseline','candidate'].map(v=>[v,report.pairs.filter(p=>operationalSuccess(p.runs[v])).length/report.pairs.length]));
 const successDelta=rates.candidate-rates.baseline;
 results.comparisons[label]={rows,requiredHuman:humanReviewSet(report,judged),operationalNonInferiority:{rates,delta:successDelta,floor:-.05,status:successDelta>=-.05?'pass':'fail',qualification:'Goal + settled, no error/censor/route mismatch; race-window comparability is reported separately. Mechanical fixture oracle, not a substitute for semantic history review.'},improvement:{validPairs:stable.length,decisive,wins,losses,winRate:decisive?wins/decisive:null,lossRate:stable.length?losses/stable.length:null,status:decisive>=10&&wins/decisive>=.6&&losses/stable.length<=.2?'judge-floor-met-human-pending':'inconclusive-or-failed'},scope:'Observed coverage includes incomparable histories; validGoalRate and paired statistics retain race restrictions. Token means use known values only; missing values prevent a pass.'};
}
ledger.recordedFailedAttempts={formal:supplement.attempts.filter(a=>a.report==='formal-triplets.json').length,diagnostics:supplement.attempts.filter(a=>a.report!=='formal-triplets.json').length,afterCutoff:supplement.attempts.filter(a=>a.afterEpisode).length,unknownUsage:supplement.attempts.filter(a=>!finite(a.usage.totalTokens)).length,readErrors:supplement.readErrors.length};
ledger.afterSettlement={completedResponses:supplement.lateCompleted.length,knownCostUSD:sum(supplement.lateCompleted.map(a=>price(a.usage)).filter(finite)),unknownCostResponses:supplement.lateCompleted.filter(a=>!finite(price(a.usage))).length,qualification:'Additional to frozen episode snapshots; any nonzero count requires closure review before claiming full episode coverage.'};
write('analysis.json',results);write('cost-ledger.json',ledger);
console.log(JSON.stringify({episodes:all.length,candidate:source.candidate,ledger,comparisons:Object.fromEntries(Object.entries(results.comparisons).map(([k,v])=>[k,v.rows.map(r=>({family:r.family,validPairs:r.validPairs,gates:r.gates}))]))},null,2));
