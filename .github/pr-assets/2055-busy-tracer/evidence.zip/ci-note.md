Full-test attempt 1 failed only the unchanged Computer upload cleanup test (`transfer-io.test.ts:79`); [failure and investigation #2125](https://github.com/BotHarness/DeepSeekBot/issues/2125). Both exact baseline and candidate pass its six isolated local tests. This does not establish a fix. One bounded rerun of failed CI jobs has been requested; retain attempt 1 rather than reporting a clean first pass.

Static checks/build, docs, mobile bundles, isolated Host smoke and full shards 2/3 passed. The earlier initial workflow was cancelled when `ci:full` started this full run.

The fixed model cohort remains at runtime/runner `ac41a433b45965789cfda2683079feb07d70d3b7`. PR head `71ce266d35e02da8017690c7a0ed8a11665ebf6e` adds screenshots only. No runtime mutation or replacement model attempts during the cohort.
