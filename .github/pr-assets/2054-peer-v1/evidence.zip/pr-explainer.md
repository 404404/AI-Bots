---
title: 同伴答完后，Bot 还需要说什么？
subtitle: "#2054 · PR #2104 · 正式评估完成，等待 Human 复评"
lang: zh
template: doc
theme: paper
base: f103902165d0b682b089174d3139b927fb1efadb
head: 7a55ab5e945284134973178a06e529c44d89786d
date: 2026-10-18
---

## A 要解决的体验

两位 Bot 同时处理请求。B 先回答，A 发送前发现群聊已变化，进入 held 复核。

A 要判断自己是否还欠必要内容。已被覆盖的重复回复可以静默放弃；独立证据、纠正和新的直接问题仍须处理。

这张图解释设计，不是实测截图。Human 尚未验收本片，合并与部署均未获授权。

## B 谁决定，谁核对

```sequence
Bot B -> Channel: 提交正式答复
Bot A -> Channel: 提交旧观察下的草稿
Channel --> Bot A: held + 新消息正文 + observationId + peerMessageIds
Bot A -> Bot A: 比较请求、同伴答复与剩余责任
Bot A -> Channel: drop + 观察凭据 + 同伴消息 IDs
Channel -> Channel: 核对 owner、观察内容与当前正式消息
Channel --> Bot A: dropped / explicit-peer-yield
```

Host 核对引用是否真实有效。是否已充分回答，由模型判断；同伴先发言本身不会完成任务。

## C Prompt 和工具契约

| 层 | 本片新增 |
|---|---|
| System Prompt | 比较剩余责任；没有增量时不发“没有补充”；保留独立证据与新问题 |
| held 结果 | peerMessageIds 标出已完整返回的同伴正式消息 |
| channel_send | yield_to_message_ids 配合 drop、draft_id、observation_id |
| 持久记录 | 原草稿 JSON 保存 yieldedToMessageIds |
| Inbox | 只有显式选择的已完成事项才结清 |

```json
{
  "channel_id": "group-id",
  "body": "",
  "drop": true,
  "draft_id": "held-draft-id",
  "observation_id": "host-issued-observation",
  "yield_to_message_ids": ["observed-peer-message-id"]
}
```

以上 ID 为说明用占位符。CLI 的 bot-tool 命令直接执行同一工具，不需要模型。

## D 拒绝与边界

未观察、已更改、被清除、Human、自己或仅草稿预览的消息，不能作为有效让话依据。

引用不合格时返回 peer-answer-not-observed；不会把草稿记为已放弃，也不会自动完成 Inbox。

复核仍沿用 #2053 的 Channel owner、权限与原子提交检查。忙群策略及中断恢复分别属于 #2055、#2056。

回退本片即可恢复 #2053 行为，本片不新增数据库迁移。但共享 Prompt 可能影响必要回复，必须评估遗漏风险。

## E 实测结果与限制

正式运行完成：40 组三臂对话，共 120 次。模型盲评交换左右各一遍，共 160 次调用。助手已核对全部历史和评审理由。

| 项目 | 相对已接受的 #2053 |
|---|---|
| 重复回答 | 10/10 次降至 5/10 次；有效竞争配对仅 6 组 |
| 独立证据 | 机械覆盖 9/10；另一次已由 Aura 补全，却因等 Atlas 发言而超时 |
| 新直接问题 | 新版 10/10 回答正确；基线 8/10 |
| FYI / 明确请求 | 三臂均正确区分，未观察到额外改善 |
| 明确请求 p95 | 3.001 秒 vs 2.834 秒，增加 5.9%，在本项预算内 |
| Token | 重复与独立证据的已知均值增加约 29% / 28%；缺失用量使预算结论不确定 |

相对 B0，重复场景 p95 为 5.306 秒 vs 4.008 秒，增加 32.4%，超过 30% 预算。独立证据另有超时与长尾，不能只看成功回复的延迟。

LLM 在两对照中均仅有 2 个有效、双顺序一致的决胜样本，未达到 10 个的最低要求。部分理由误套其他场景的 QA-317 要求；原判与助手异议均保留。

正式 Host 已知费用约 $1.0052，13 次运行完整费用未知。已完成响应的另一种下界估算为 $1.1253，不能与 Host 费用相加。评审已知费用约 $0.1903，另一次调用失败、费用未知。

## F 交付与 Human 复评

| 验证 | 状态 |
|---|---|
| 当前 PR CI | 适用检查通过；完整矩阵与 CI 模型场景跳过 |
| 真实 Host CLI | held、无效引用拒绝、主动让话、新问题提交通过 |
| Web Client | 同一组真实模型历史的前后截图已保存，控制台无错误 |
| 离线卡片 | 左右选择、撤销、刷新、导出及窄屏均已验证 |
| Human / 合并部署 | 尚未复评 #2054；保持草稿，未合并或部署 |

解压 review.zip，打开 index.html。先选择左右、差不多或不好判断，再查看 token、费用与评审。完整私聊准备轮在每张卡片底部。导出 JSON 后发回；下载失败可复制结果文本。

两个对照页各 40 组，共享同一批新版历史。看过另一页会影响独立性，导出会记录浏览器可见的交叉阅读情况。

本页绑定 PR head 7a55ab5；实测运行版本为 ba62052。后续提交只补充报告、文档和截图，没有更改实测运行代码。#2053 的延迟例外不自动适用于本片。

源码：[Prompt 与工具](https://github.com/BotHarness/DeepSeekBot/blob/ba6205269820d55945a7add32c05adfa1d04cdc6/packages/core/src/runtime/dsh-bot-agent-adapter.ts) · [观察核对 owner](https://github.com/BotHarness/DeepSeekBot/blob/ba6205269820d55945a7add32c05adfa1d04cdc6/packages/core/src/channels/send-review.ts) · [预登记](https://github.com/BotHarness/DeepSeekBot/issues/2054#issuecomment-6238030939)
