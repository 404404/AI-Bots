# #2056 formal v1: complete records, not accepted

Candidate `9c61b4575041bcf1361e155eaf5d27fd5882b451`; Bi `390630e0dc81b0e776758bc420c1622b2ad51981`; B0 `73056fc59dcac42c3fd7e6cb1586f6c1c4e37157`. Registered in issue comment 6244891509. Run ended 2026-10-18 05:02:24 UTC. All 40 fixed triplets / 120 attempted episodes were read by the current GPT-6 Astra assistant from actual Group/DM history, native Tools and visible Session text. No external judge calls, independent blind order or Human votes are claimed. Four repeated synthetic families are not forty distinct real-world situations.

## Findings

- Held restart: candidate 10/10 corrected completion, no observed unauthorized output. Bi 5/10 all-attempt corrected completion; one Bi case never reached the fault. B0 never reaches held/restart and is incomparable for recovery, not a stale-answer failure.
- Committed response loss: candidate 8/8 exposed cases preserve the exact canonical message ID and commit counts. Two prelude transport failures prevent fault exposure; planned coverage remains 8/10 and the safety gate is inconclusive. No replacement samples.
- Terminal refusal: 10/10 exposed and no unauthorized send/leak. However, two revoked-membership cases also block a new neutral DM, so settled task completion is 8/10. This is a real defect. The later combined commit has a targeted startup fix, not verified by this cohort.
- Quiet: all ten candidate conversations correct, no extra model Turns against Bi. Candidate p95 reply is 21.272s versus Bi 3.064s (6.943x), failing 1.10x. The slow candidate case has provider TRANSPORT errors before and after its actual send, no held/recheck. Do not claim the recovery step caused the delay or discard it. Known-subset mean Host-token ratio is 1.1293 versus budget 1.05; incomplete accounting makes the whole-token gate inconclusive, not a pass.
- Held-recovery known-subset mean Host-token ratio is 0.8916 versus Bi, but missing usage, unfinished Bi responsibility and one missed exposure prevent budget acceptance.
- Direct C/Bi judgments: 14 wins, 2 losses, 19 ties, 5 insufficient. C/B0: 2 wins, 0 losses, 16 ties, 22 insufficient. The subjective floor is met; this does not override the failed or inconclusive gates.

## Accounting and limits

Known cumulative Host-runtime cost subtotals: candidate USD0.193823184; Bi USD0.189321642; B0 USD0.189911070. These are not complete episode/provider totals. Four candidate and four Bi episodes have unknown runtime cost; B0 quiet4 has a failed final usage fetch. Nine failed native provider attempts remain recorded (5 candidate,4 Bi). Native completed cost is a separate estimate and must never be added to Host cost. Auxiliary native title-generation usage and review cost remain unknown; no invoice claim. Fixed model alias/pricing is in the protocol; underlying alias revision and cache state are uncontrolled.

Candidate response-loss3/9 stopped during prelude infrastructure failures; unobserved future responsibility is not counted as zero. Failed, censored and unexposed attempts remain in denominators. All native exports contain no late completed events at the recorded accounting cutoff; this does not establish future behavior after that cutoff.

Combined install/build/test work approximately04:28–04:40 UTC overlapped refusal-family runs on the same machine. Quiet began04:43. Preserve that scheduling confound without attributing any individual latency to it. No timing sample is excluded.

Public purge projections omit all plaintext and Tool payloads for the six actually purged arms; exact private source hashes, order, IDs, usage, scores and tombstones remain. The assistant read authorized pre-purge history privately. The public projection is intentionally not a complete plaintext copy of those six arms. Actual final-snapshot redaction qualification passed all six arms.

## Disposition

Keep PR2156 draft and #2056 open. No merge, closure or deployment on this cohort. The #2053 latency exception is not inherited. Preserve this failed/inconclusive cohort separately from the registered three combined diagnostics (comment6245825559) and future formal validation. The combined diagnostics cannot substitute for the 40-triplet acceptance cohort or silently waive its budgets.
