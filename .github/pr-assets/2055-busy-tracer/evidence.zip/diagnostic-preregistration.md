### First busy-Group tracer and bounded diagnostic

Task: `codex/local/01a14906-16cc-7800-a569-b5c812c02eef`.

Candidate frozen at `ac41a433b45965789cfda2683079feb07d70d3b7`; accepted incremental baseline is `390630e0dc81b0e776758bc420c1622b2ad51981`, rebuilt in its own isolated Host. Do not substitute an earlier #2054 Host: the final merge also includes intervening main changes. Original B0 remains `73056fc59dcac42c3fd7e6cb1586f6c1c4e37157` for the later formal comparison.

The production-shaped direct CLI tracer passed: initial held, two rechecks, exhausted budget, no new-draft reset, wrong-owner/version/observation refusals, exactly one explicit override commit and refused replay. Real Web history shows one reply, zero console errors. The first export requested 30 trace turns (maximum 20); its history and failure are retained, then the exporter was corrected. Local regression preserves two Windows 15-second test timeouts; the final focused run uses a disclosed 30-second per-test limit and passes. Runtime model deadline remains 240 seconds.

Before the unchanged four-family/ten-pair formal cohort, run exactly **one chatter A/B pair (two attempts), no replacements**, to qualify the live interference barrier. Two real preceding Group turns establish facts; 20 unrelated messages at at most two per second begin on the first outgoing draft. Same official DeepSeek route, reasoning off and frozen 2026-10-17 pricing; all Bots, preparation, follow-up, failures and unknown usage count. The existing Session runner and usage helpers are reused.

Current GPT-6 Astra reads the complete actual DSH conversations and native Tool records directly. No external judge requests or invented Human scores. This diagnostic does not establish p95 or replace formal budgets. Formal registration will bind its final runner hash and candidate before starting those fixed runs. No deployment.
