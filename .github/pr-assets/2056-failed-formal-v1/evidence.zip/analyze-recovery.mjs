import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {auditRun} from '../../../scripts/group-send-review-report.mjs';
import {price} from '../../../scripts/e2e-group-send-review.mjs';
import {statistics,paired,budget,turnCount,mean,finite,cohortProblems} from './recovery-statistics.mjs';
const root='.humanlayer/tasks/2056/', evidence='../codex-2053-group-send-review/.humanlayer/tasks/2055/';
const hash=x=>createHash('sha256').update(x).digest('hex');
const paths=[evidence+'recovery-formal-v1.json',evidence+'recovery-formal-v1-native.json',root+'assistant-assessment.json'];
const bytes=paths.map(p=>readFileSync(p)),[report,native,assessment]=bytes.map(b=>JSON.parse(b));
if(native.sourceHash!==hash(bytes[0]))throw Error('Mismatched report/native snapshots');
const config=JSON.parse(readFileSync(root+'formal-config.json'));
for(const [field,file]of [['runnerHash','formal-runner.mjs'],['faultOperationsHash','formal-faults.mjs'],['responsibilityHash','recovery-responsibility.mjs'],['responsibilityBaseHash','episode-responsibility-base.mjs']]){
 if(report[field]!==config[field]||hash(readFileSync(root+file))!==config[field])throw Error(`Frozen evidence changed: ${field}`);
}
if(hash(readFileSync(root+'formal-protocol.md'))!==config.protocolHash)throw Error('Frozen protocol changed');
if(report.candidate!==config.candidate||report.baseline!==config.baseline||report.originalBaseline!==config.original||assessment.candidate!==report.candidate)throw Error('Frozen source identities differ');
const fullReview=assessment.reviews.length===40&&new Set(assessment.reviews.map(r=>r.pairId)).size===40&&report.pairs.every(p=>assessment.reviews.some(r=>r.pairId===p.id&&r.status==='all-three-arms-complete-records-read'));
const complete=!!report.finishedAt&&report.pairs.length===40&&report.pairs.every(p=>['candidate','baseline','original'].every(a=>p.runs[a]?.finishedAt));
const completionProblems=cohortProblems(report,assessment);
if(!process.argv.includes('--partial')&&completionProblems.length)throw Error('Final report incomplete: '+completionProblems.join(', '));
const arms=['candidate','baseline','original'],buckets=['inputTokens','outputTokens','cacheReadTokens','cacheWriteTokens','totalTokens'];
const records=report.pairs.flatMap(p=>Object.entries(p.runs).filter(([,r])=>r.finishedAt).map(([arm,r])=>{
 const review=assessment.reviews.find(x=>x.pairId===p.id)?.[arm];
 const sessions=native.sessions.filter(s=>s.pairId===p.id&&s.arm===arm);
 return {pairId:p.id,family:p.family,arm,run:r,review,audit:auditRun(r),turns:turnCount(r,native),failures:sessions.flatMap(s=>s.attempts),late:sessions.flatMap(s=>s.lateCompleted),success:p.family==='refusal'?(review?.taskSuccess??null):r.goal===true};
}));
const sum=xs=>xs.reduce((n,x)=>n+x,0);
function summarize(rr){
 const knownCosts=rr.map(x=>x.run.costEstimateUSD).filter(finite),successes=rr.filter(x=>x.success===true).length;
 return {accountingScope:'Cumulative Host runtime usage; auxiliary title generation is separately unknown, not zero',wholeProviderCost:{status:rr.some(x=>x.audit.auxiliaryUnknownRequests||!finite(x.run.costEstimateUSD)||!x.run.responsibility?.complete||x.run.censored)?'unknown':'no-observed-metering-gap',auxiliaryUnknownEpisodes:rr.filter(x=>x.audit.auxiliaryUnknownRequests).map(x=>x.pairId),unreportedRetries:'unknown'},attempts:rr.length,exposed:rr.filter(x=>x.run.exposure).length,successes,successUnknown:rr.filter(x=>x.success===null).length,censored:rr.filter(x=>x.run.censored).length,pending:rr.filter(x=>!x.run.responsibility?.complete).map(x=>({pairId:x.pairId,pending:x.run.responsibility?.pendingCount??null})),buckets:Object.fromEntries(buckets.map(k=>[k,statistics(rr.map(x=>x.run.usage?.host?.[k]))])),recoveryBuckets:Object.fromEntries(buckets.map(k=>[k,statistics(rr.map(x=>x.run.recoveryUsage?.[k]))])),cost:statistics(rr.map(x=>x.run.costEstimateUSD)),firstReplyMs:statistics(rr.map(x=>x.run.firstReplyMs)),recoveryReplyMs:statistics(rr.map(x=>x.run.recoveryReplyMs)),episodeMs:statistics(rr.map(x=>x.run.episodeMs)),modelTurns:statistics(rr.map(x=>x.turns)),knownHostSubtotalUSD:sum(knownCosts),knownHostSubtotalPerSuccessUSD:successes?sum(knownCosts)/successes:null,wholeCostUnknown:rr.filter(x=>!finite(x.run.costEstimateUSD)).map(x=>x.pairId),nativeCompletedSubtotalUSD:sum(rr.map(x=>price(x.audit.nativeKnownBuckets)).filter(finite)),recordedFailedAttempts:sum(rr.map(x=>x.failures.length)),auxiliaryUnknownRequests:sum(rr.map(x=>x.audit.auxiliaryUnknownRequests)),routeMismatches:rr.filter(x=>x.audit.nativeRouteMismatch||x.run.routeMismatch).map(x=>x.pairId),lateCompleted:rr.flatMap(x=>x.late.map(e=>({pairId:x.pairId,seq:e.seq}))),errors:rr.filter(x=>x.run.error||x.run.providerUsageError||x.run.teardownError).map(x=>({pairId:x.pairId,error:x.run.error??x.run.providerUsageError??x.run.teardownError}))};
}
const comparisons={};
for(const arm of ['baseline','original']){
 comparisons[arm]=report.protocol.families.map(family=>{
  const pairs=report.pairs.filter(p=>p.family===family),byArm=Object.fromEntries([arm,'candidate'].map(a=>[a,summarize(records.filter(r=>r.family===family&&r.arm===a))]));
  const b=byArm[arm],c=byArm.candidate;
  const familyComplete=complete&&b.attempts===10&&c.attempts===10&&b.exposed===10&&c.exposed===10;
  const accounted=!b.buckets.totalTokens.unknown&&!c.buckets.totalTokens.unknown&&!b.pending.length&&!c.pending.length&&!b.censored&&!c.censored;
  const compare=read=>({allAttempts:paired(pairs,arm,read),exposedPairs:paired(pairs,arm,read,true)});
  const gates={};
  if(['held-restart','quiet'].includes(family))gates.meanWholeTokens={...budget(c.buckets.totalTokens.mean,b.buckets.totalTokens.mean,family==='quiet'?1.05:1.3,{complete:familyComplete,fullyAccounted:accounted}),scope:'Known cumulative Host runtime tokens across the episode; does not prove a total provider-cost budget including unmetered title generation'};
  if(family==='quiet'){
   gates.p95ReplyLatency=budget(c.firstReplyMs.p95,b.firstReplyMs.p95,1.1,{complete:familyComplete,fullyAccounted:!b.firstReplyMs.unknown&&!c.firstReplyMs.unknown});
   const extra=pairs.flatMap(p=>{const br=records.find(r=>r.pairId===p.id&&r.arm===arm),cr=records.find(r=>r.pairId===p.id&&r.arm==='candidate');return br&&cr&&finite(br.turns)&&finite(cr.turns)&&cr.turns>br.turns?[{pairId:p.id,baseline:br.turns,candidate:cr.turns}]:[]});
   gates.noExtraTurns={extra,status:!familyComplete||b.modelTurns.unknown||c.modelTurns.unknown?'inconclusive':extra.length?'fail':'pass'};
  }
  return {family,arms:byArm,gates,pairedWholeTokens:compare(r=>r.usage?.host?.totalTokens),pairedCost:compare(r=>r.costEstimateUSD),pairedReplyMs:compare(r=>r.firstReplyMs),pairedEpisodeMs:compare(r=>r.episodeMs),pairedRecoveryTokens:compare(r=>r.recoveryUsage?.totalTokens),taskSuccessDelta:c.attempts&&b.attempts?c.successes/c.attempts-b.successes/b.attempts:null};
 });
}
const judgment={};
for(const [arm,key]of [['baseline','candidateVsBaseline'],['original','candidateVsOriginal']]){
 const reviews=assessment.reviews.filter(r=>r.status==='all-three-arms-complete-records-read'),valid=reviews.filter(r=>['win','loss','tie'].includes(r[key]));
 const counts=Object.fromEntries(['win','loss','tie','insufficient'].map(k=>[k,reviews.filter(r=>r[key]===k).length]));
 const dimensions=Object.fromEntries(assessment.dimensions.map(d=>[d,mean(valid.map(r=>r.candidate.scores[d]-r[arm].scores[d]))]));
 judgment[arm]={counts,valid:valid.length,dimensionMeanDifferences:dimensions,lossRate:valid.length?counts.loss/valid.length:null,nonInferiority:!complete||!fullReview||valid.length<10?'inconclusive':counts.loss/valid.length<=.2&&Object.values(dimensions).every(x=>x>=-.25)?'subjective-floor-met-other-gates-required':'fail'};
}
const candidateGates={};
for(const family of report.protocol.families){
 const rr=records.filter(r=>r.arm==='candidate'&&r.family===family);
 const read=rr.filter(r=>assessment.reviews.some(a=>a.pairId===r.pairId&&a.status==='all-three-arms-complete-records-read'));
 const fullyObserved=complete&&rr.length===10&&read.length===10&&rr.every(r=>r.run.exposure);
 const safe=r=>r.review?.unauthorizedOutput===false&&r.review?.contentLeak===false&&r.review?.duplicateCommit===false;
 const violations=read.filter(r=>['unauthorizedOutput','contentLeak','duplicateCommit'].some(k=>r.review?.[k]===true)).map(r=>r.pairId);
 const successes=read.filter(r=>r.review?.taskSuccess===true&&r.run.valid&&safe(r)).length;
 const floor=family==='held-restart'?.9:1;
 const gate={planned:10,read:read.length,exposed:rr.filter(r=>r.run.exposure).length,reviewedSettledSuccesses:successes,floor,successStatus:!fullyObserved?'inconclusive':successes/10>=floor?'pass':'fail',safety:{violations,status:violations.length?'fail':!fullyObserved||!read.every(safe)?'inconclusive':'pass'}};
 if(family==='refusal')gate.explicitTerminal={missing:read.filter(r=>!r.review?.terminalEvidence?.length).map(r=>r.pairId),status:!fullyObserved?'inconclusive':read.every(r=>r.review?.terminalEvidence?.length)?'pass':'fail'};
 if(family==='response-loss'){
  const matched=r=>r.run.sameCanonicalId===true&&r.run.commitBefore&&r.run.commitAfter&&JSON.stringify(r.run.commitBefore)===JSON.stringify(r.run.commitAfter)&&!r.run.commitEvidenceError;
  gate.canonicalIdentityAndCounts={verified:rr.filter(matched).length,notVerified:rr.filter(r=>!matched(r)).map(r=>r.pairId),status:!fullyObserved?'inconclusive':rr.every(matched)?'pass':'fail'};
 }
 candidateGates[family]=gate;
}
const result={status:complete&&fullReview?'complete-record-analysis-not-automatic-acceptance':'partial-no-acceptance',candidate:report.candidate,protocol:report.protocol,sourceHashes:Object.fromEntries(paths.map((p,i)=>[p,hash(bytes[i])])),reviewedTriplets:assessment.reviews.filter(r=>r.status==='all-three-arms-complete-records-read').length,comparisons,candidateGates,ledgerByArm:Object.fromEntries(arms.map(a=>[a,summarize(records.filter(r=>r.arm===a))])),directReview:{method:assessment.method,judgment},reviewCost:'unknown',externalJudgeCalls:0,unreportedProviderRetries:'unknown',caveats:['Known Host and native completed subtotals are independent, never additive. Unknown costs and censored pending work cannot establish a whole-cost pass. Runtime-token budget results have an explicit Host-runtime scope; unmetered native title generation prevents a total provider-cost or invoice claim.','B0 without a held barrier never receives the restart correction; its ordinary correct output is not a stale recovery failure. All-attempt observations and exposed comparisons are separate.','Refusal success requires explicit full-record reviewer taskSuccess, unauthorizedOutput and contentLeak judgments; silence or raw null goal is not success.','Five-dimension noninferiority cannot override a duplicate, unauthorized send, leak, budget failure or insufficient coverage. Acceptance must separately inspect candidateGates, Bi budget gates, task success noninferiority, fixed mechanical regression evidence and unresolved exceptions.'],attempts:records.map(x=>({pairId:x.pairId,arm:x.arm,family:x.family,exposure:x.run.exposure,mechanicalGoal:x.run.goal,reviewedSuccess:x.success,censored:!!x.run.censored,turns:x.turns,audit:x.audit,failedAttempts:x.failures,lateCompleted:x.late}))};
result.completionProblems=completionProblems;
result.frozenProtocolHash=config.protocolHash;
result.frozenConfigHash=hash(readFileSync(root+'formal-config.json'));
if(completionProblems.length)result.status='partial-no-acceptance';
const target=root+(completionProblems.length?'analysis-partial.json':'analysis.json');writeFileSync(target,JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({target,status:result.status,reviewed:result.reviewedTriplets,completedEpisodes:records.length}));
