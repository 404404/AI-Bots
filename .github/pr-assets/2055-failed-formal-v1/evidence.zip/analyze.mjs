import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {pairedInterval,auditRun} from '../../../scripts/group-send-review-report.mjs';
import {price,taskOutputs} from '../../../scripts/e2e-group-send-review.mjs';
const root='.humanlayer/tasks/2055/';
const source=JSON.parse(readFileSync(root+'formal-v1.json','utf8'));
if(!source.finishedAt)throw Error('Formal cohort is unfinished; do not publish final statistics');
const native=JSON.parse(readFileSync(root+'formal-v1-native.json','utf8'));
const hash=x=>createHash('sha256').update(JSON.stringify(x)).digest('hex');
const finite=x=>typeof x==='number'&&Number.isFinite(x);
const sum=x=>x.reduce((n,v)=>n+v,0);
const mean=x=>x.length?sum(x)/x.length:null;
const q=(x,p)=>x.length?x.slice().sort((a,b)=>a-b)[Math.ceil(x.length*p)-1]:null;
const stats=x=>({n:x.filter(finite).length,unknown:x.filter(v=>!finite(v)).length,mean:mean(x.filter(finite)),median:q(x.filter(finite),.5),p95:q(x.filter(finite),.95)});
const ratio=(a,b)=>finite(a)&&finite(b)&&b!==0?a/b:null;
const parsed=x=>{try{return JSON.parse(x)}catch{return undefined}};
const mechanism=r=>{
 const tools=(r.providerUsage??[]).flatMap(s=>s.toolCalls??[]);
 const sends=tools.filter(t=>t.name==='channel_send').map(t=>({...t,args:parsed(t.arguments),out:parsed(t.result)}));
 const groups={};for(const t of sends){const id=t.out?.draftId??t.args?.draft_id;if(id){groups[id]??={maxRechecks:0,overrides:0,successfulOverrides:0};groups[id].maxRechecks=Math.max(groups[id].maxRechecks,t.out?.budget?.used??0);if(t.args?.freshness_override){groups[id].overrides++;if(t.out?.messageId)groups[id].successfulOverrides++;}}}
 return {drafts:groups,held:sends.filter(t=>t.out?.status==='held').length,requiresReview:sends.filter(t=>t.out?.status==='requires-review').length,refusals:sends.filter(t=>t.out?.status==='refused').length,snoozes:tools.filter(t=>t.name==='inbox_snooze').length,sendCalls:sends.length,publicReplies:r.sourceStartedAt?taskOutputs(r).length:0};
};
// Outcome failure is not missing experimental exposure. Keep all attempts/costs.
const exposed=r=>!!r.sourceStartedAt && !r.error && !r.streamError && !r.interventionError && !r.routeMismatch && (r.family==='revoke-or-quiet'?(r.index%2===0||!!r.revokedAt):r.family==='defer'?!!r.conditionAt&&!!r.resumeAt:r.intervention?.length===20) && (r.family==='revoke-or-quiet'&&r.index%2===0||r.windowHit===true);
const correctionTiming=r=>{
 if(r.family!=='correction'||!r.sourceStartedAt)return null;
 const injection=r.intervention?.find(x=>x.body.startsWith('关键纠正：'));
 const at=injection?.completedAt;
 const replies=taskOutputs(r).filter(x=>x.channelId===r.group);
 const before=at?replies.filter(x=>Date.parse(x.message.at)<Date.parse(at)):[];
 const obsolete=at?replies.filter(x=>Date.parse(x.message.at)>=Date.parse(at)&&(/10[:：]00/.test(x.message.body)||/A-101/.test(x.message.body))):[];
 return {correctionCompletedAt:at??null,initialReplyBeforeCorrection:before.length>0,preCorrectionMessageIds:before.map(x=>x.message.id),possibleObsoletePostCorrectionMessageIds:obsolete.map(x=>x.message.id),note:'A reply before the correction cannot be judged to have ignored it at commit. Regex matches are review candidates: an explicit statement that the old room is cancelled is not an obsolete answer. Episode adoption and at-commit freshness are distinct; native turn timing needs full record review.'};
};
const records=source.pairs.flatMap(p=>Object.entries(p.runs).map(([arm,r])=>{
 const scope=native.sessions.filter(s=>s.pairId===p.id&&s.arm===arm);
 return {pairId:p.id,family:p.family,subfamily:p.family==='revoke-or-quiet'?(r.index%2===0?'quiet':'revoke'):p.family,arm,run:r,attemptStarted:!!r.sourceStartedAt,completeExposure:exposed(r),qualifiedMechanicalGoal:!!r.sourceStartedAt&&r.goal===true,operationalSuccess:!!r.sourceStartedAt&&r.goal===true&&r.valid===true,audit:auditRun(r),correctionTiming:correctionTiming(r),mechanism:mechanism(r),recordedFailures:scope.flatMap(s=>s.attempts??[]),lateCompleted:scope.flatMap(s=>s.lateCompleted??[])};
}));
const comparison={};
for(const [label,arm] of [['bi','baseline'],['b0','original']]){
 const rows=[];
 for(const family of ['chatter','correction','defer','revoke','quiet']){
  const byArm={};
  for(const a of [arm,'candidate']){
   const rr=records.filter(x=>x.subfamily===family&&x.arm===a);
   byArm[a]={planned:rr.length,started:rr.filter(x=>x.attemptStarted).length,completeExposure:rr.filter(x=>x.completeExposure).length,valid:rr.filter(x=>x.run.valid).length,qualifiedMechanicalGoals:rr.filter(x=>x.qualifiedMechanicalGoal).length,operationalSuccess:rr.filter(x=>x.operationalSuccess).length,censored:rr.filter(x=>x.run.censored).length,errors:rr.filter(x=>x.run.error).map(x=>({pair:x.pairId,error:x.run.error})),tokens:stats(rr.map(x=>x.run.usage?.host?.totalTokens)),cost:stats(rr.map(x=>x.run.costEstimateUSD)),replyLatencyMs:stats(rr.map(x=>x.attemptStarted?x.run.firstReplyMs:null)),episodeMs:stats(rr.map(x=>x.run.episodeMs)),buckets:Object.fromEntries(['inputTokens','outputTokens','cacheReadTokens','cacheWriteTokens','totalTokens'].map(k=>[k,stats(rr.map(x=>x.run.usage?.host?.[k]))])),failures:sum(rr.map(x=>x.recordedFailures.length)),nativeCompletedTokens:stats(rr.map(x=>x.audit.nativeKnownBuckets.totalTokens)),mechanisms:rr.map(x=>({pairId:x.pairId,...x.mechanism}))};
  }
  const pairs=source.pairs.filter(p=>(p.family==='revoke-or-quiet'?(p.runs.candidate.index%2===0?'quiet':'revoke'):p.family)===family);
  const valid=pairs.filter(p=>exposed(p.runs[arm])&&exposed(p.runs.candidate));
  const paired=(read,selected=valid)=>{const vals=selected.map(p=>[read(p.runs[arm]),read(p.runs.candidate)]).filter(x=>x.every(finite));const deltas=vals.map(([b,c])=>c-b);return {n:vals.length,meanDelta:mean(deltas),ci95:pairedInterval(deltas,2055)}};
  const b=byArm[arm],c=byArm.candidate,complete=b.completeExposure===b.planned&&c.completeExposure===c.planned;
  const gate=(a,b,limit,known)=>{const r=ratio(a,b);return {ratio:r,limit,status:!complete||!known||r===null?'inconclusive':r<=limit?'pass':'fail',knownSubsetExceeds:r===null?null:r>limit}};
  rows.push({family,arms:byArm,comparableExposurePairs:valid.length,allAttemptPairedTokens:paired(r=>r.usage?.host?.totalTokens,pairs),allAttemptPairedCost:paired(r=>r.costEstimateUSD,pairs),pairedTokens:paired(r=>r.usage?.host?.totalTokens),pairedCost:paired(r=>r.costEstimateUSD),pairedLatencyMs:paired(r=>r.firstReplyMs),gates:{meanTokens:gate(c.tokens.mean,b.tokens.mean,family==='quiet'?1.05:1.25,!c.tokens.unknown&&!b.tokens.unknown),p95Tokens:family==='quiet'?null:gate(c.tokens.p95,b.tokens.p95,1.5,!c.tokens.unknown&&!b.tokens.unknown),quietP95Latency:family==='quiet'?gate(c.replyLatencyMs.p95,b.replyLatencyMs.p95,1.1,!c.replyLatencyMs.unknown&&!b.replyLatencyMs.unknown):null,success:{rate:c.operationalSuccess/c.planned,limit:family==='revoke'?1:.9,status:c.operationalSuccess/c.planned>=(family==='revoke'?1:.9)?'mechanical-floor-met-review-required':'not-met'},nonInferiority:{delta:c.operationalSuccess/c.planned-b.operationalSuccess/b.planned,floor:-.05}}});
 }
 comparison[label]=rows;
}
const ledger=rr=>({episodes:rr.length,successfulGoals:rr.filter(x=>x.operationalSuccess).length,knownHostCostPerSuccessfulGoal:rr.some(x=>x.operationalSuccess)?sum(rr.map(x=>x.run.costEstimateUSD).filter(finite))/rr.filter(x=>x.operationalSuccess).length:null,costPerSuccessCoverage:'All attempted episode known costs divided by complete-protocol mechanical goals; unknown costs make this a partial subtotal, not full unit cost. Zero successes is undefined.',hostKnownCostUSD:sum(rr.map(x=>x.run.costEstimateUSD).filter(finite)),hostUnknown:rr.filter(x=>!finite(x.run.costEstimateUSD)).map(x=>[x.pairId,x.arm]),nativeCompletedKnownCostUSD:sum(rr.map(x=>price(x.audit.nativeKnownBuckets)).filter(finite)),auxiliaryUnknownRequests:sum(rr.map(x=>x.audit.auxiliaryUnknownRequests)),recordedFailedAttempts:sum(rr.map(x=>x.recordedFailures.length)),lateCompleted:rr.flatMap(x=>x.lateCompleted.map(e=>({pairId:x.pairId,arm:x.arm,...e}))),unreportedProviderRetries:'unknown',externalJudgeCalls:0});
const result={sourceHash:hash(source),nativeHash:hash(native),candidate:source.candidate,protocol:source.protocol,comparisons:comparison,ledger:ledger(records),ledgerByArm:Object.fromEntries(['baseline','candidate','original'].map(a=>[a,ledger(records.filter(r=>r.arm===a))])),ledgerByFamilyAndArm:Object.fromEntries(['chatter','correction','defer','revoke','quiet'].map(f=>[f,Object.fromEntries(['baseline','candidate','original'].map(a=>[a,ledger(records.filter(r=>r.arm===a&&r.subfamily===f))]))])),oracleCaveat:'Frozen raw goal may incorrectly match a preparatory reply when prelude failed before the target. Derived goal requires sourceStartedAt; raw values are retained. Mechanical correctness does not assess all obsolete extras or speculative claims; full-record assistant judgments remain separate.',denominatorCaveat:'Unknown or invalid episodes remain in planned-denominator task success. All-attempt paired cost includes finite recorded failures and preparation failures, without success selection. Exposed-pair estimates also include censored task failures when the full controlled input arrived. Missing experimental exposure/unknown cost prevents a gate pass. Raw valid additionally requires task settlement and is not used to remove failed-baseline consumption. B0 revocation exposure may be absent. In correction fixtures B0 often sends before message eight arrives, whereas held candidates are still reviewing. Inspect correctionTiming and full records: whole-episode goal rates alone do not prove equal in-flight correction exposure or that B0 ignored an available correction.',attempts:records.map(({run:r,...x})=>({...x,valid:r.valid,error:r.error,censored:r.censored,windowHit:r.windowHit,rawGoal:r.goal,sourceStartedAt:r.sourceStartedAt,group:r.group,hostUsage:r.usage?.host}))};
writeFileSync(root+'analysis.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({ledger:result.ledger,comparisons:Object.fromEntries(Object.entries(comparison).map(([k,v])=>[k,v.map(x=>({family:x.family,exposed:x.comparableExposurePairs,gates:x.gates}))]))},null,2));
