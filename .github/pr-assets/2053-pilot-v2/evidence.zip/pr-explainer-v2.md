---
title: "群聊发送复核 · PR #2066"
subtitle: 在 held 结果中交付新增上下文，减少一次模型往返
lang: zh
template: doc
theme: paper
PR: https://github.com/BotHarness/DeepSeekBot/pull/2066
base: 0b19f8871da0bb22669583c51350404af73d4ec4
evalBaseline: 73056fc59dcac42c3fd7e6cb1586f6c1c4e37157
head: 0d50b0669788d04d49a4c2dfe4afc495ad786f35
generated: 2026-10-17
---
Human 纠正会议时间后，旧草稿先暂存，Bot 读到纠正再提交。
这次将有界新增内容直接放进 held 结果，省去单独的 channel_read。
代码说明绑定上面的 head。固定第二轮评估也使用这个 head。

本轮纠正成功 10/10，基线为 0/10。
纠正与无关旁话的 token 增幅仍超过 25% 预算。
另有两例撤权后转发到 DM 的体验反例，PR 保持草稿。

## A 一次纠正如何改变发送
```timeline v
01 | 完整观察 | Host 记录已交付的消息范围与内容指纹。
02 | 原子检查 | 检查与正式 append 在同一事务。
03 | held | 有变化时保留草稿，并返回有界新增内容。
04 | 一次重交 | Bot 使用新观察句柄修改、原文重交或 drop。
05 | 显式收尾 | Bot 处理完后调用 inbox_resolve；未完成责任保持打开。
```
返回内容不全时，Bot 仍需读取缺失消息。
再次变化、过期或 Host 重启时，停止自动发送。

## B 哪个模块拥有事实
| 事实 | 所有者与边界 |
|---|---|
| 已交付内容 | Host 观察句柄绑定 Bot、Session、Group 和内容指纹 |
| 正式消息 | 原 Channel append 事务检查后，写入 Source Event 与 placement |
| 未提交草稿 | GroupSendReview 持久记录保存正文、观察依据与重交次数 |
| 新增上下文 | 复用 channel_read 的裁剪与内容边界，仅完整交付内容进入观察范围 |
| Inbox 责任 | 读取加入当前轮；Bot 显式确认完成，发送和 drop 均不自动完成责任 |
| Human 评审 | ZIP 内两张完整历史卡片；先选左右，再主动揭盲 |

[草稿与观察句柄](https://github.com/BotHarness/DeepSeekBot/blob/0d50b0669788d04d49a4c2dfe4afc495ad786f35/packages/core/src/channels/send-review.ts) · [held 内容交付](https://github.com/BotHarness/DeepSeekBot/blob/0d50b0669788d04d49a4c2dfe4afc495ad786f35/packages/core/src/runtime/bot-runtime.ts#L5954)

## C 省在哪里，边界在哪里
| 选择 | 代价或限制 |
|---|---|
| held 返回有界内容 | 省去一次单独读取；仍需模型决定修改或保留 |
| 最多 20 条，整体 12000 字符上限 | 超限保留原有读取路径；遗漏正文不能伪装成已读 |
| 不猜测消息相关性 | 无关旁话仍会触发复核；成本须实测 |
| 最多一次明确重交 | 持续忙群与恢复属于后续 slice |
| Group 显式启用 | 默认关闭；关闭开关可回退行为 |
| schema generation 96 | 旧二进制不能直接打开新代数 Profile |

二进制回退需要升级前备份或兼容迁移。
审查重点是事务、owner 隔离、内容 purge 和 held 不产生正式消息。

## D 验证证据与限制
固定四类各十对，B0 与 Bi 均为上面的 evalBaseline。
双方运行 Node 24.16.0、DSH 0.2.0-rc.2，使用官方 DeepSeek 路由。
模型、价格、预算和判定窗口保持冻结。第一轮结果仅作历史对照。

| 层次 | 证据 |
|---|---|
| 机械回归 | 62 项相关测试通过；最终责任说明后再次通过 9 项核心测试 |
| 工程检查 | lint、根 TypeScript 检查、相关格式与 build 通过 |
| 真实 CLI | 不额外读取，直接使用 held 观察句柄完成改稿提交 |
| 真实 Web | 打开对应 Group，对照正式历史与控制台 |
| 模型与成本 | 40 对完整记录；失败保留，不补换样本；分析见档案 |
| 体验评审 | 双顺序 LLM 盲评后，助手核查历史和引用；Human 再独立选左右 |

标题请求和未上报重试的用量未知，费用小计不能视为完整账单。
Human 接受、合并与部署仍未完成，后续三个 slice 保持门禁。
这份说明是审查辅助材料，不替代运行证据或 Human 反馈。
