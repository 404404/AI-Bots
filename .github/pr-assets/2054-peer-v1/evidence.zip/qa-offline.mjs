import {createRequire} from 'node:module';
import {readdirSync,readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
const task=resolve('.humanlayer/tasks/2054'),store=resolve('node_modules/.pnpm');
const pp=createRequire(join(store,readdirSync(store).find(n=>n.startsWith('puppeteer@')),'node_modules','/'))('puppeteer');
const browser=await pp.launch({headless:true,args:['--no-sandbox']});
const result={at:new Date().toISOString(),workflow:'Repository verify-app headless Chromium; actual extracted file URLs, plus collaborative HTTP browser separately',checks:[],errors:[]};
const check=(name,value)=>{assert(value,name);result.checks.push(name)};
try{
 const page=await browser.newPage();page.on('pageerror',e=>result.errors.push(e.message));
 await page.setViewport({width:1280,height:900});
 const url=name=>pathToFileURL(join(task,'offline-review',name)).href;
 await page.goto(url('index.html'));
 await page.waitForSelector('[data-choice="Left"]');
 const state=()=>page.evaluate(()=>({status:document.querySelector('#status').textContent,exported:JSON.parse(document.querySelector('#export-text').value),reveal:document.querySelector('#revealbox').textContent}));
 let s=await state();check('file page initializes with 40 unreviewed histories',s.exported.unreviewed.length===40);
 check('judge and costs hidden before independent choice',!s.reveal);
 await page.click('[data-choice="Left"]');s=await state();check('one click saves and advances',s.exported.ratings['redundant-1'].winner==='Left'&&s.status.includes('第 2 /'));
 await page.reload();s=await state();check('choice survives file reload',s.exported.ratings['redundant-1'].winner==='Left');
 await page.click('[data-choice="Right"]');await page.click('#undo');s=await state();check('undo restores prior choice and keeps history',s.exported.ratings['redundant-1'].winner==='Left'&&s.exported.ratings['redundant-1'].history.length>0);
 await page.click('[data-choice="Right"]');await page.click('#review-last');s=await state();check('reveal follows independent choice and shows token lower bounds',s.reveal.includes('全部 Bot tokens')&&s.reveal.includes('费用下界'));
 await page.click('[data-choice="Left"]');s=await state();check('post-reveal revision is explicitly marked',s.exported.ratings['redundant-1'].alreadyRevealed===true);
 const downloads=join(task,'qa-downloads',String(Date.now()));mkdirSync(downloads,{recursive:true});
 const cdp=await page.createCDPSession();await cdp.send('Browser.setDownloadBehavior',{behavior:'allow',downloadPath:downloads});
 await page.click('#export');
 for(let i=0;i<100&&!readdirSync(downloads).some(n=>n==='2054-human-review-bi.json');i++)await new Promise(r=>setTimeout(r,100));
 const downloaded=JSON.parse(readFileSync(join(downloads,'2054-human-review-bi.json'),'utf8'));
 s=await state();check('download JSON equals text backup',JSON.stringify(downloaded)===JSON.stringify(s.exported));
 check('backup is visible after export',await page.$eval('#export-backup',e=>e.open));
 await page.goto(url('original.html'));s=await state();check('second comparison has independent choices',s.exported.comparison==='b0'&&s.exported.unreviewed.length===40);
 await page.click('#tie');s=await state();
 result.fileCrossComparisonExposure=s.exported.ratings['redundant-1'].otherComparisonReview;
 // Chromium file storage can be partitioned by file; report the observed boundary honestly.
 await page.setViewport({width:390,height:844});
 check('narrow page has no document horizontal overflow',await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
 await page.screenshot({path:join(task,'review-file-narrow.png'),fullPage:false});
 check('both full-history cards and preparatory DM disclosures exist',await page.evaluate(()=>document.querySelectorAll('.conversation').length===2&&[...document.querySelectorAll('.conversation summary')].some(e=>e.textContent.includes('私聊'))));
 for(const name of ['index.html','original.html']){await page.goto(url(name));await page.evaluate(()=>{for(const k of Object.keys(localStorage))if(k.startsWith('bh2054-human-')&&/-offline-2054-(bi|b0)-v1$/.test(k))localStorage.removeItem(k)});await page.reload();s=await state();check(name+' synthetic votes cleared',s.exported.unreviewed.length===40);}
 check('no uncaught page errors',result.errors.length===0);
 result.passed=true;
}catch(e){result.passed=false;result.failure=e.message;throw e;}finally{writeFileSync(join(task,'review-qa-file.json'),JSON.stringify(result,null,2)+'\n');await browser.close();}
console.log(JSON.stringify(result));
