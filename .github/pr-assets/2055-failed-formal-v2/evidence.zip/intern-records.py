import json, pathlib, sys
from collections import Counter
p=pathlib.Path(sys.argv[1])
lines=p.read_text(encoding='utf-8').splitlines()
records=[];counts=Counter()
def key(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def visit(v):
    if isinstance(v,dict):
        assert '$exactRef' not in v
        k=key(v)
        if len(k)>40:counts[k]+=1
        for c in v.values():visit(c)
    elif isinstance(v,list):
        for c in v:visit(c)
for line in lines:
    pos=line.find('{')
    try:v=json.loads(line[pos:]) if pos>=0 and not line.startswith('Repeated exact strings:') else None
    except ValueError:v=None
    records.append((line[:pos],v,line))
    if v is not None:visit(v)
refs={k:'O'+str(i+1) for i,(k,n) in enumerate((x for x in counts.items() if x[1]>1))}
def transform(v,skip=None):
    if isinstance(v,dict):
        k=key(v)
        if k in refs and k!=skip:return {'$exactRef':refs[k]}
        return {k:transform(c) for k,c in v.items()}
    if isinstance(v,list):return [transform(c) for c in v]
    return v
definitions={name:transform(json.loads(k),k) for k,name in refs.items()}
def expand(v):
    if isinstance(v,dict):
        if '$exactRef' in v:return expand(definitions[v['$exactRef']])
        return {k:expand(c) for k,c in v.items()}
    if isinstance(v,list):return [expand(c) for c in v]
    return v
out=[]
for prefix,v,line in records:
    if v is None:out.append(line);continue
    compact=transform(v)
    assert expand(compact)==v, 'Lossless roundtrip required'
    out.append(prefix+json.dumps(compact,ensure_ascii=False,separators=(',',':')))
out.insert(1,'Repeated exact objects: '+json.dumps(definitions,ensure_ascii=False,separators=(',',':')))
dest=p.with_name(p.stem+'-interned.txt');dest.write_text('\n'.join(out)+'\n',encoding='utf-8')
print(json.dumps({'file':str(dest),'objects':len(definitions),'before':p.stat().st_size,'after':dest.stat().st_size,'roundtrip':'pass'}))
