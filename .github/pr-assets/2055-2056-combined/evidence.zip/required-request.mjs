export function inspectRequiredRequest(db,{channelId,messageId,botSlug}){
 const row=db.prepare(`SELECT p.source_event_id,a.bot_slug,a.opened_at,a.resolved_at,a.ignored_at,a.snoozed_until FROM channel_placements p LEFT JOIN inbox_admissions a ON a.source_event_id=p.source_event_id AND a.bot_slug=? WHERE p.channel_id=? AND p.message_id=?`).get(botSlug,channelId,messageId);
 return {channelId,messageId,botSlug,row:row??null,complete:!!row?.bot_slug&&!!(row.resolved_at||row.ignored_at)};
}
