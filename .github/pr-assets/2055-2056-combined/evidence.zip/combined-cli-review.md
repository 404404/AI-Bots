# Combined470d direct CLI proof

Same real isolated Host/Tool code, no model used for the two CLI Bots. Original run `combined-cli-proof.json` halted after a safe stale-observation refusal: expected override-context-not-observed, actual recovery-requires-draft-and-fresh-observation/statusrefused. That is an assertion expectation mismatch, not a successful bypass. Preserve the first run.

First same-record continuation failed before its read because original teardown had paused the two test Bots. Preserve `combined-cli-continuation.json`; no new commit occurred. The next continuation explicitly resumed exactly those two silent-Group test Bots and continued the **same Group and original exhausted draft**, then paused them in finally. `combined-cli-continuation-resumed.json` passes. A Python default-encoding preparation error preceded these continuation executions and did not mutate the Host.

Actual checks: two-recheck budget exhausted before restart; inspected draft requiresRecovery; stale old observation safely refuses; fresh-read wrong-owner send refuses draft-unavailable; fresh recovery+oneoverride commits one correct11/B204/R3message. Receipt retains attempts2/overridecount1 and clears copied bodies. Second Hostrestart, same-intent replay returns original canonical message ID. Placement, Admission, receipt and DM action-notice records remain exactly unchanged. Different body refuses draft-commit-content-changed. Group history contains exactly one Botmessage with corrected facts. Full direct trace retained. No model-quality/budget inference from this mechanical proof.

Web check pending. The collaborative browser was opened during intentional native restarts and retained connection failures. After fresh login and entering Botmode it rendered the correct Group preview, but two Group-row clicks left the Tob home selected. No recent console errors on those clicks. Clientdiagnostics recorded shell-lost then remounted during Botmode transition; preserve combined-after-cli-observe.json (exit1) and earlier startupobserve(unobserved). The repository verify-app shot is being used to independently drive the same actual Group, not to declare the earlier failures fixed.


## Completed UI proof

The first shot timed out: the Group row was selected while Home stayed active. It remains a failure, not a fixed panel-switch claim. A second explicit journey opened Messages, then selected the same Group. `combined-cli-messages-history` passed with zero console issues; the screenshot and complete ARIA show original10/A101, FYIs, Human11/B204 correction, and exactly one Ada11/B204/R3 notice. Both screenshots and console files are retained. This proves the actual history is reachable through Messages.
