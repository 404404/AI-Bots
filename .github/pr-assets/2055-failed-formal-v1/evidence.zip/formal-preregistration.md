### Fixed #2055 busy-Group cohort

Task: `codex/local/01a14906-16cc-7800-a569-b5c812c02eef`.

Freeze candidate and runner at `ac41a433b45965789cfda2683079feb07d70d3b7`, incremental baseline at accepted #2054 merge `390630e0dc81b0e776758bc420c1622b2ad51981`, and original B0 at `73056fc59dcac42c3fd7e6cb1586f6c1c4e37157`. Each runs its own isolated, authenticated DSH 0.2.0-rc.2 Host. The original B0 Host has been requalified by doctor; new Bots/Sessions are created for every episode. No deployment.

Run exactly four families × ten matched triplets (120 planned episodes), alternating arm order and at most two concurrent triplets. No replacement attempts or success-only reruns. Each family is ten stochastic repeats of one controlled synthetic fixture, not ten distinct real-world conversations. Two genuine preceding Group exchanges establish facts. Protocol `2055-busy-v1` is committed in `scripts/e2e-group-busy-review.mjs`; its immutable source and the report's protocol hash bind all timing and oracle rules.

1. Twenty unrelated Human messages, at most two/second, beginning on the first nonempty outgoing draft.
2. Same stream with a time/room correction in message eight.
3. Human requests waiting until a timestamp 30 seconds away; confirms material R4 after 15 seconds, without mentioning the Bot. Necessary work must complete after both conditions in the same episode.
4. Five membership revocations after the observed `requires-review` boundary and five quiet controls. B0 has no such boundary: absent exposure is recorded as censored/incomparable, never a successful refusal. Naturally missed windows in other arms are also retained.

Use `DEEPSEEK_API_KEY`, `deepseek-official/deepseek-flash@off`, identical provider defaults, unsupported seed, new Sessions without claiming cold provider caches. Price version remains the frozen 2026-10-17 estimate from #2053, not a billing assertion. Count both Bots, preparation, all destinations, follow-ups, failures and unknown usage. The 240-second whole-episode deadline is unchanged; settlement/export time is recorded. Host usage is the primary measure. A null Host bucket remains unknown even when completed Session responses provide a separately labelled subtotal. Auxiliary title calls and unreported provider retries remain unknown.

The earlier excluded diagnostic completed both arms with correct, single Group notices. Candidate performed exactly two rechecks and one reasoned override; baseline reached terminal refusals then created another draft on a subsequent turn. First correct reply: candidate 8.596s, baseline 18.918s. Candidate Host total 343,112 tokens / estimated $0.006437004; baseline Host total unknown (completed Session subtotal 459,821 tokens). No statistical or general improvement claim follows from one pair. Full histories and native Tools are retained.

The current GPT-6 Astra assistant reads actual full conversation histories, native Tool arguments/results, visible assistant text and failure records. This is an unblinded engineering assessment, with zero external judge calls and no invented Human votes. Automated goal checks are preliminary and cannot excuse obsolete extra replies, unwanted acknowledgments, or other quality regressions. Keep original thresholds: necessary-task success at least 90%; automatic rechecks ≤2; override ≤1; busy mean tokens ≤1.25×Bi and p95 tokens ≤1.5×Bi; quiet mean tokens ≤1.05×Bi and p95 latency ≤1.1×Bi. Report uncertainty and every unmet budget explicitly. The Human authorized merge of checked work, not fabricated passing measurements.
