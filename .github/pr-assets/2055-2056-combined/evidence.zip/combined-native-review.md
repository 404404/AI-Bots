# Combined470d native qualification — direct records

Current assistant read complete real Group/DM/native Tool and visible text exports; no external judge or acceptance from mechanical goal. v1three cases remain immutable; v2one corrected-observer revoke case separately registered6246024498 now complete. root2055/combined-revoke-read-compact-interned.txt, combined-held-loss-read-compact-interned.txt and combined-revoke-v2-read-compact-interned.txt read in full including all exact legends; canonical responsibility/cost/commit facts separately checked.

## v1 refusal2 — NOT QUALIFIED, observer failure

Old original Admission Host-ignored05:15:30.144 after real revoke/restart. New neutral Human DM05:15:33.261. Observer falsely settles05:15:34.789 while new turn4step1 starts; teardown stops it05:15:36.188 before any response. Actual DM contains request and stopped event, no answer. No old fact leaked. Hostcost unknown; native completed133599tokens before interrupted turn,49.444swhole. Rawvalid:true is overridden: premature test cutoff, no semantic/task-success qualification, not evidence the product blocked DM. Preserve failed attempt62usageunknown. Missing explicit neutral-Admission and idle-window reset fixed only in separately registeredv2helper; no alteration to v1/formal records.

## v1 held restart1 — narrow qualification passes

Realheld49interrupted by Host restart after11:00/B204correction. Same owning Session65inspect67fullfreshread75recover original draft→one actual correct notice. Original+correction completionIDsresolved.81tries redundant public explanation, Hostholds;87drops it and resolves the recovery request,93Inbox0. Private98truthful; no redundant public message, unauthorized/duplicate/leak. Notice includes all3original agenda topics/R3. Scores[5,4,5,5,5],taskSuccess true. Four native Turns,323696Hosttokens,$.006528696,70.315swhole/19.527starget. No providerfailedattempt or lateevent. Extra held/drop of unnecessary status response is retained as friction. Original request and new recovery request actually resolved before cutoff, so the v1observer bug did not truncate this case.

## v1 response loss1 — narrow qualification passes

49actualsend commits notice but Tool result is replaced with unknown outcome.55inspect sees exact committed ID61reads that message67redundantlyresolves alreadyResolved original. No resend. Same canonical ID,1placement/1Admission/1receipt unchanged before/after; oneactualcorrect10/A101/R3notice andall3agenda topics. Private54/72accurately explain uncertainty then verification. Scores[5,4,5,5,5],taskSuccess true.3Turns9completedSteps246053Hosttokens,$.00525105,51.372swhole/1.981starget. No providerfailedattempt or lateevent. Original responsibility genuinelysettled; native verification completes before cutoff. Not a formal10case proof or budget result.

## v2 refusal2 — new DM delivery repair qualified, wording defect retained

Actualheld61interrupted; Group membership removed; original Admission Host-ignored05:18:58.782. New neutral DM05:19:04.495;76inspect refuses draft-access-unavailable,82channel_list no-accessible-match,88actualDMdelivered05:19:10.145,97originalresolve112newDMresolve. ExactnewDMAdmission resolved05:19:31.308 before05:19:44.905cutoff;0pending. No old meeting facts republished, no unauthorized Group send. Same owning Session, fresh newDMturn4. Old source fence no longer blocks requested DM.

The actual DM incorrectly infers that inaccessible means no draft exists. It should say the draft cannot be inspected, not that none exists. It also exposes tool codes unnecessarily. [3,3,4,4,3], necessary neutral status delivered/safe stop succeeds, quality defect remains. No total-quality or acceptance claim.5Turns14completedSteps,90.452swhole; nativecompleted385659tokens, Hostwholecostunknown after nativeTRANSPORT92duringpostsendcleanup. Private102 repeats the same unsupported absence inference;117accurately confirms final newDMsettlement. No late output. The earlier v1 premature-cutoff record remains a failed qualification attempt, not overwritten.
