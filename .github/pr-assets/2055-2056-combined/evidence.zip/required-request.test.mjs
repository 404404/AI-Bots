import {test}from'node:test';import assert from'node:assert/strict';import{DatabaseSync}from'node:sqlite';import{inspectRequiredRequest}from'./required-request.mjs';
test('new neutral DM must settle even before admission opens',()=>{
 const db=new DatabaseSync(':memory:');db.exec('CREATE TABLE channel_placements(source_event_id TEXT,channel_id TEXT,message_id TEXT);CREATE TABLE inbox_admissions(source_event_id TEXT,bot_slug TEXT,opened_at TEXT,resolved_at TEXT,ignored_at TEXT,snoozed_until TEXT)');
 const input={channelId:'dm-b',messageId:'new',botSlug:'b'};
 assert.equal(inspectRequiredRequest(db,input).complete,false);
 db.exec("INSERT INTO channel_placements VALUES('new-source','dm-b','new')");assert.equal(inspectRequiredRequest(db,input).complete,false);
 db.exec("INSERT INTO inbox_admissions VALUES('new-source','b',NULL,NULL,NULL,NULL)");assert.equal(inspectRequiredRequest(db,input).complete,false);
 db.exec("INSERT INTO inbox_admissions VALUES('old','b',NULL,NULL,'ignored',NULL)");assert.equal(inspectRequiredRequest(db,input).complete,false);
 db.exec("UPDATE inbox_admissions SET snoozed_until='future' WHERE source_event_id='new-source'");assert.equal(inspectRequiredRequest(db,input).complete,false);
 db.exec("UPDATE inbox_admissions SET resolved_at='done' WHERE source_event_id='new-source'");assert.equal(inspectRequiredRequest(db,input).complete,true);db.close();
});
