import {readFileSync} from 'node:fs';
import {basename} from 'node:path';

// A live runner writes synchronously, but a separate reader can see its partial write.
// Retry only parsing that transient snapshot; never retry or replace an episode.
export function readJsonSnapshot(path) {
  for (let attempt = 0; attempt < 8; attempt++) {
    const bytes = readFileSync(path);
    try {
      const value = JSON.parse(bytes.toString('utf8'));
      if (attempt) process.stderr.write(`Read snapshot ${basename(path)} after ${attempt} partial-write retries\n`);
      return {value, bytes};
    } catch (error) {
      if (!(error instanceof SyntaxError) || attempt === 7) throw error;
      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 25);
    }
  }
}
