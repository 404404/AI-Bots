import {readFileSync,writeFileSync,readdirSync,existsSync} from 'node:fs';
import {join} from 'node:path';
import {zstdDecompressSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const root='.humanlayer/tasks/2054/';
if(existsSync(root+'failed-attempts.json'))throw Error('Retain the existing immutable supplement; do not overwrite');
const read=p=>JSON.parse(readFileSync(p,'utf8'));
const formal=read(root+'formal-triplets.json');
if(!formal.finishedAt)throw Error('Collect supplement only after the frozen run completes');
const instances={baseline:'../qa-2054-bi/.humanlayer/verify/peer-review-2054-bi/instance.json',original:'../qa-2053-baseline/.humanlayer/verify/send-review-2053-ingest-base/instance.json',candidate:'.humanlayer/verify/peer-review-2054-formal/instance.json'};
const groups=Object.entries(instances).map(([arm,path])=>({instance:read(path),episodes:formal.pairs.map(p=>({report:'formal-triplets.json',pairId:p.id,arm,run:p.runs[arm]}))}));
for(const [file,path] of [['diagnostic-redundant.json','.humanlayer/verify/peer-review-2054/instance.json'],['diagnostic-redundant-v2.json','.humanlayer/verify/peer-review-2054-v2/instance.json'],['diagnostic-independent.json','.humanlayer/verify/peer-review-2054-v2/instance.json']]){
 const r=read(root+file);
 for(const arm of ['baseline','candidate'])groups.push({instance:read(arm==='baseline'?instances.baseline:path),episodes:r.pairs.map(p=>({report:file,pairId:p.id,arm,run:p.runs[arm]}))});
}
const walk=d=>readdirSync(d,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(join(d,e.name)):e.name==='session.v4.jsonl.zstd'?[join(d,e.name)]:[]);
const result={at:new Date().toISOString(),sourceHash:createHash('sha256').update(JSON.stringify(formal)).digest('hex'),scope:'Additive native assistant/attempt evidence and late completed-response audit; frozen histories, metrics and validity unchanged. No thought/content chunks exported. Events after an episode cutoff are labeled separately.',attempts:[],lateCompleted:[],readErrors:[]};
for(const {instance,episodes} of groups){
 const slugs=new Map(episodes.flatMap(e=>Object.values(e.run.bots??{}).map(s=>[s,e])));
 for(const file of walk(join(instance.home,'sessions'))){
  try{
   let bytes=readFileSync(file),text='';while(bytes.length){const x=zstdDecompressSync(bytes,{info:true});if(!x.engine.bytesWritten)throw Error('zstd made no progress');text+=x.buffer.toString();bytes=bytes.subarray(x.engine.bytesWritten);}
   const events=text.trim().split('\n').filter(Boolean).map(JSON.parse),h=events.find(e=>e.type==='session');
   const slug=[...slugs.keys()].find(s=>h?.cwd?.replaceAll('\\','/').includes('/bots/'+s+'/'));if(!slug)continue;
   const episode=slugs.get(slug);
   for(const event of events.filter(e=>e.type==='assistant/message'&&e.time>Date.parse(episode.run.finishedAt)))result.lateCompleted.push({report:episode.report,pairId:episode.pairId,arm:episode.arm,botSlug:slug,sessionId:h.id,seq:event.seq,at:event.time,usage:Object.fromEntries(['inputTokens','outputTokens','cacheReadTokens','cacheWriteTokens','totalTokens'].map(k=>[k,typeof event.data?.usage?.[k]==='number'?event.data.usage[k]:null]))});
   for(const event of events.filter(e=>e.type==='assistant/attempt')){
    const stream=event.data?.stream??[],sample=event.data?.usage??stream.findLast(x=>x.chunk?.type==='usage')?.chunk?.usage;
    const failures=stream.filter(x=>x.chunk?.type==='finish').map(x=>({kind:x.chunk.reason?.kind,code:x.chunk.reason?.failure?.code,message:x.chunk.reason?.failure?.message}));
    result.attempts.push({report:episode.report,pairId:episode.pairId,arm:episode.arm,botSlug:slug,sessionId:h.id,seq:event.seq,at:event.time,turn:event.data?.turn,step:event.data?.step,afterEpisode:event.time>Date.parse(episode.run.finishedAt),failures,usage:Object.fromEntries(['inputTokens','outputTokens','cacheReadTokens','cacheWriteTokens','totalTokens'].map(k=>[k,typeof sample?.[k]==='number'?sample[k]:null]))});
   }
  }catch(error){result.readErrors.push({arm:episodes[0]?.arm,fileName:'session.v4.jsonl.zstd',errorKind:error.name});}
 }
}
writeFileSync(root+'failed-attempts.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({attempts:result.attempts.length,lateCompleted:result.lateCompleted.length,readErrors:result.readErrors.length,codes:[...new Set(result.attempts.flatMap(a=>a.failures.map(f=>f.code)))]}));
