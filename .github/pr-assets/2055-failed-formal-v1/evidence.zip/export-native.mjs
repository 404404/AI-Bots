import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { zstdDecompressSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { readJsonSnapshot } from './read-report.mjs';
const root = '.humanlayer/tasks/2055/';
const sourceName = process.argv[2] ?? 'formal-v1.json';
const arg = (key, fallback) => process.argv.includes(key) ? process.argv[process.argv.indexOf(key) + 1] : fallback;
const snapshot = readJsonSnapshot(root + sourceName);
const report = snapshot.value;
const instances = {
  baseline: arg('--baseline-instance', '../qa-2055-bi/.humanlayer/verify/busy-review-2055-bi/instance.json'),
  candidate: arg('--candidate-instance', '.humanlayer/verify/busy-review-2055/instance.json'),
  original: arg('--original-instance', '../qa-2053-baseline/.humanlayer/verify/send-review-2053-ingest-base/instance.json'),
};
const walk = d => readdirSync(d, { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(join(d, e.name)) : e.name === 'session.v4.jsonl.zstd' ? [join(d, e.name)] : []);
const result = { sourceName, sourceHash: createHash('sha256').update(snapshot.bytes).digest('hex'), capturedAt: new Date().toISOString(), sessions: [], errors: [] };
for (const [arm, path] of Object.entries(instances)) {
  const wanted = new Map(report.pairs.flatMap(p => Object.values(p.runs[arm]?.bots ?? {}).map(slug => [slug, { pairId: p.id, arm, cutoff: p.runs[arm].finishedAt }])));
  if (wanted.size === 0) continue;
  const instance = JSON.parse(readFileSync(path, 'utf8'));
  for (const file of walk(join(instance.home, 'sessions'))) {
    let text = '';
    try {
      let bytes = readFileSync(file);
      while (bytes.length) {
        const d = zstdDecompressSync(bytes, { info: true });
        if (!d.engine.bytesWritten) throw Error('No decompression progress');
        text += d.buffer.toString('utf8'); bytes = bytes.subarray(d.engine.bytesWritten);
      }
      const events = text.trim().split('\n').filter(Boolean).map(JSON.parse);
      const header = events.find(e => e.type === 'session');
      const botSlug = [...wanted.keys()].find(slug => header?.cwd?.replaceAll('\\', '/').includes(`/bots/${slug}/`));
      if (!botSlug) continue;
      const scope = wanted.get(botSlug);
      const s = { ...scope, botSlug, sessionId: header.id, newOverrideToolPresent: events.some(e => e.type === 'request/header' && JSON.stringify(e.data).includes('freshness_override')), assistantText: [], attempts: [], extraTools: [], lateCompleted: [] };
      const allowed = new Set(['channel_send', 'channel_read', 'inbox_resolve', 'inbox_read', 'inbox_list', 'inbox_snooze']);
      const extraIds = new Set(events.filter(e => e.type === 'tool/call' && !allowed.has(e.data.name)).map(e => e.data.callId));
      for (const e of events) {
        if (e.type === 'assistant/message') {
          const blocks = e.data.message?.content?.filter(c => c.type === 'text').map(c => c.text) ?? [];
          if (blocks.length) s.assistantText.push({ seq: e.seq, at: e.time, turn: e.data.turn, step: e.data.step, text: blocks });
          if (scope.cutoff && e.time > Date.parse(scope.cutoff)) s.lateCompleted.push({ seq: e.seq, at: e.time, usage: e.data.usage ?? null });
        }
        if (e.type === 'assistant/attempt') s.attempts.push({ seq: e.seq, at: e.time, turn: e.data.turn, step: e.data.step, finishes: e.data.stream?.filter(x => x.chunk?.type === 'finish').map(x => ({ at: x.time, reason: x.chunk.reason })), usage: e.data.usage ?? null });
        if ((e.type === 'tool/call' && extraIds.has(e.data.callId)) || (e.type === 'tool/result' && extraIds.has(e.data.message?.toolCallId))) s.extraTools.push({ seq: e.seq, at: e.time, type: e.type, data: e.data });
      }
      result.sessions.push(s);
    } catch (error) { result.errors.push({ arm, reason: error.message }); }
  }
}
writeFileSync(root + sourceName.replace('.json', '-native.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ sessions: result.sessions.length, attempts: result.sessions.reduce((n,s)=>n+s.attempts.length,0), late: result.sessions.reduce((n,s)=>n+s.lateCompleted.length,0), extra: result.sessions.filter(s=>s.extraTools.length).map(s=>({pair:s.pairId,arm:s.arm,tools:s.extraTools.filter(t=>t.type==='tool/call').map(t=>t.data.name)})), errors: result.errors }));
