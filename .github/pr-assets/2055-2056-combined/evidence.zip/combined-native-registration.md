### Bounded combined-runtime qualification registration

Task `codex/local/01a14906-16cc-7800-a569-b5c812c02eef`, active. Candidate `470d174b25dcf9bd2faad702e100d680e68b9ea6`, combined #2055/#2056 integration. The independent frozen cohorts remain unchanged and are not replaced or pooled with this diagnostic.

After both the existing #2056 formal controller and queued #2055 cleanup controller finish, run exactly three sequential candidate-only DSH episodes in one fresh isolated Profile: (1) native held result, remove Bot membership while the old task is active, restart that exact Profile, then ask a neutral new Human DM; (2) native held result, append11:00/B-204 correction, restart and explicitly recover; (3) discard one actual committed Tool result and observe whether the Bot verifies the same canonical message rather than duplicating it. No replacement attempts or automatic formal rerun.

Reuse the actual native Tool fault fixture, scenario context/usage collector, canonical responsibility reader and formal episode mechanics. Official DeepSeek Flash/effort off, DEEPSEEK_API_KEY and the frozen2026-10-17 price estimate remain. The new verification RPC uses Connection:close and never automatically retries an uncertain mutation. Each episode has240seconds from the first background input including restart, all-Bot usage, original/observed/snoozed responsibility settlement, twelve-second idle/usage stability and explicit cutoff before teardown. Failed/unexposed/censored attempts, unknown provider/title/reviewer cost and late output are retained.

The current assistant reads full DSH Session, Tool, Group and DM histories directly. Require one actual neutral new-DM reply with no old facts or restored revoked task in case1; one corrected notice in case2; one canonical commit and no duplicate placement/Admission in case3. These qualify mechanisms, not formal reliability, cost or latency gates. Separate model-free direct CLI exercises exhaustion+restart+fresh observation+one override+same receipt replay; the Web Client must show the actual resulting conversation and clean diagnostics.

Runner SHA256 `957a3842563db8a83d46b9f12d1d8d3f532f1e99da876084056e1cef95d65382`.
Fault operations `0d12812d86ae950c3d7630b0631a34dbb897d8bb9ae9df6ba5ca272c6bca7aff`.
Responsibility reader `7ee74f2604dcba8ce116c9f69f3f46fcc9b4378a39ba5ff785e9cf0bbe523c4f`; base `03b1f454483c43716fd11e784dee3ffaf08d3b1fc4cea2a15d1ca6ca325de5eb`.
Native fixture `98e8dcab81552d0b3bfbf9097de12f1f68c514d859d3a4ac27495d5e2b2cebbd`.

No acceptance, PR merge, issue closure or deployment follows automatically from these diagnostics.
